///////////////////////////////////////////////////
///////////////////////////////////////////////////
///////////////////////////////////////////////////
	const time_t seed = time(0);
	const int dx[] = { 0, 1, 0, -1, 1, 1, -1, -1 }, dy[] = { -1, 0, 1, 0, -1, 1, 1, -1 };
	
	// 枚举定义；使用枚举虽然会浪费空间（sizeof(GridContentType) == 4），但是计算机处理32位的数字效率更高
 
	// 每个格子可能变化的内容，会采用“或”逻辑进行组合
	enum GridContentType
	{
		empty = 0, // 其实不会用到
		player1 = 1, // 1号玩家
		player2 = 2, // 2号玩家
		player3 = 4, // 3号玩家
		player4 = 8, // 4号玩家
		playerMask = 1 | 2 | 4 | 8, // 用于检查有没有玩家等
		smallFruit = 16, // 小豆子
		largeFruit = 32 // 大豆子
	};
 
	// 用玩家ID换取格子上玩家的二进制位
	GridContentType playerID2Mask[] = { player1, player2, player3, player4 };
	string playerID2str[] = { "0", "1", "2", "3" };
 
	// 让枚举也可以用这些运算了（不加会编译错误）
	template<typename T>
	inline T operator |=(T &a, const T &b)
	{
		return a = static_cast<T>(static_cast<int>(a) | static_cast<int>(b));
	}
	template<typename T>
	inline T operator |(const T &a, const T &b)
	{
		return static_cast<T>(static_cast<int>(a) | static_cast<int>(b));
	}
	template<typename T>
	inline T operator &=(T &a, const T &b)
	{
		return a = static_cast<T>(static_cast<int>(a) & static_cast<int>(b));
	}
	template<typename T>
	inline T operator &(const T &a, const T &b)
	{
		return static_cast<T>(static_cast<int>(a) & static_cast<int>(b));
	}
	template<typename T>
	inline T operator ++(T &a)
	{
		return a = static_cast<T>(static_cast<int>(a) + 1);
	}
	template<typename T>
	inline T operator ~(const T &a)
	{
		return static_cast<T>(~static_cast<int>(a));
	}
 
	// 每个格子固定的东西，会采用“或”逻辑进行组合
	enum GridStaticType
	{
		emptyWall = 0, // 其实不会用到
		wallNorth = 1, // 北墙（纵坐标减少的方向）
		wallEast = 2, // 东墙（横坐标增加的方向）
		wallSouth = 4, // 南墙（纵坐标增加的方向）
		wallWest = 8, // 西墙（横坐标减少的方向）
		generator = 16 // 豆子产生器
	};
 
	// 用移动方向换取这个方向上阻挡着的墙的二进制位
	GridStaticType direction2OpposingWall[] = { wallNorth, wallEast, wallSouth, wallWest };
 
	// 方向，可以代入dx、dy数组，同时也可以作为玩家的动作
	enum Direction
	{
		stay = -1,
		up = 0,
		right = 1,
		down = 2,
		left = 3,
		// 下面的这几个只是为了产生器程序方便，不会实际用到
		ur = 4, // 右上
		dr = 5, // 右下
		dl = 6, // 左下
		ul = 7 // 左上
	};
 
	// 场地上带有坐标的物件
	struct FieldProp             // 亦可以理解为物体的坐标……
	{
		int row, col;
		FieldProp()
		{	
		};
		
		FieldProp(const int& r, const int& c):
		row(r), col(c)
		{
			
		};
	};
	
	//有改动
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////

	
		// 判断指定位置向指定方向移动是不是合法的（没有撞墙且没有踩到豆子产生器）		
	    inline bool ActionValid(const FieldProp& p, Direction &dir)
		{
			if (dir == stay)
				return true;
			const GridStaticType &s = fieldStatic[p.row][p.col];
			return dir >= -1 && dir < 4 && !(s & direction2OpposingWall[dir]) && !(s & generator);
		}
		
		inline bool ActionValid(const int& y, const int& x, Direction &dir)
		{
			if (dir == stay)
				return true;
			const GridStaticType &s = fieldStatic[y][x];
			return dir >= -1 && dir < 4 && !(s & direction2OpposingWall[dir]) && !(s & generator);
		}	
		
		

class NodeMap
{
public:
	int height, width, totEdge; 	
	bool IsGenerator[144];                         // 标记这个节点是否有效，防止是果子产生器QAQ
	int DistTable[144][144];
	Direction DirTable[144][144];
	
	void set(const int& h, const int& w)
	{
		height = h; width = w;
		memset(IsGenerator, 0, sizeof(0));
		totEdge = 0;
	}
	
	FieldProp coord(const int& xx)                   // 将node坐标转化成原来的二维坐标
	{
		return(xx / height, xx % height);
	}
	
	int NodeID(const int& y, const int& x)           // 将二维坐标映射为一维的node坐标
	{
		return (y * height + x);
	};
	
	void CreateAdjList(GridStaticType *fieldStatic[])    // 建立邻接表
	{
		// All generator must be marked!
		for (int j = 0; j < height; ++j)
		{
			for (int i = 0; i < width; ++i)
			{
				if (fieldStatic[j][i] == generator)
				{
					IsGenerator[ID] = true;
				}
			}
		};    
		
		// make the AdjList
		for (int j = 0; j < height; ++j)
		{
			for (int i = 0; i < width; ++i)
			{
				int ID = NodeID(j ,i)l				
				Direction dir; int yn, xn;
				
				dir = up;
				yn = j + dy[dir];
				yn = (yn + height) % height;
				xn = i + dx[dir];
				xn = (xn + width) % width;
				if (!IsGenerator[yn][xn] && ActionValid(j, i, dir))
				{
					++totEdge;
					u[totEdge] = ID;
					v[totEdge] = NodeID(yn, xn);
					next[totEdge] = first[ID];
					first[ID] = totEdge;
				}
				
				dir = down;
				yn = j + dy[dir];
				yn = (yn + height) % height;
				xn = i + dx[dir];
				xn = (xn + width) % width;
				if (!IsGenerator[yn][xn] && ActionValid(j, i, dir))
				{
					++totEdge;
					u[totEdge] = ID;
					v[totEdge] = NodeID(yn, xn);
					next[totEdge] = first[ID];
					first[ID] = totEdge;
				}
				
				dir = left;
				yn = j + dy[dir];
				yn = (yn + height) % height;
				xn = i + dx[dir];
				xn = (xn + width) % width;
				if (!IsGenerator[yn][xn] && ActionValid(j, i, dir))
				{
					++totEdge;
					u[totEdge] = ID;
					v[totEdge] = NodeID(yn, xn);
					next[totEdge] = first[ID];
					first[ID] = totEdge;
				}
				
				dir = right;
				yn = j + dy[dir];
				yn = (yn + height) % height;
				xn = i + dx[dir];
				xn = (xn + width) % width;
				if (!IsGenerator[yn][xn] && ActionValid(j, i, dir))
				{
					++totEdge;
					u[totEdge] = ID;
					v[totEdge] = NodeID(yn, xn);
					next[totEdge] = first[ID];
					first[ID] = totEdge;
				}
				
			}
		}
	}
	
	void DijkstraAll()                               // 求出所有点对的路径，似乎稀疏图这样还凑活，不会Johnson算法QAQ，没看懂
	{
		for (int i = 0; i < totNode; ++i)
		{
			bool s[144];
			memset(s, 0, sizeof(s));
		}
	}
}