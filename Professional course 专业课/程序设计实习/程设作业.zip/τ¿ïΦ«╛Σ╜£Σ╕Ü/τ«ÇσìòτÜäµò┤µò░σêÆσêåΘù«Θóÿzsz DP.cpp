#include <iostream>
#include <algorithm>
using namespace std;

int Aid[55];

int main()
{
	cin.sync_with_stdio(false);
	int n;
	Aid[0] = 1;
	for (int i = 1; i < 55; ++i)
	{
		for (int j = 54; j >= i; --j)
		{
			int end = j / i;
			for (int k = 1; k <= end; ++k)
				Aid[j] += Aid[j - k * i];
		}
	}
	while (cin >> n)
	{
		cout << Aid[n] << endl;
	}
	return 0;
}