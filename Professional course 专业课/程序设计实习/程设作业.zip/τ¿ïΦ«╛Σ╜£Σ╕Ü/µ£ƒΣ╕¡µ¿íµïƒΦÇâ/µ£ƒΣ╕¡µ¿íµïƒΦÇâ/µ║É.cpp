#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		unsigned int n, i, j, res = 0;
		cin >> n >> i >> j;
		res = n & (1 << i);
		res |= ((~n) & (1 << j));
		if (i < j)
		{
			int tmp = i;
			i = j; 
			j = tmp;
		}
		unsigned int mask = 0;
		for (int k = j + 1; k < i; ++k)
		{
			mask |= 1 << k;
		}
		res |= mask;

		printf("%x\n", res);
	}
	return 0;
}