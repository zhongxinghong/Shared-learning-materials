#include<cstdio>
#include<iostream>

using namespace std;


template <class T>
T Max( T a, T b) 
{
	cout << "TemplateMax" <<endl;
	return 0;
}

//double Max(double a, double b){
//cout << "MyMax" << endl;
//return 0;
//}

main()
{
	int i=4, j=5;
	max(2,3);
	Max(1.2, 3.4); //���MyMax
	Max(i, j); //���TemplateMax
	max(1.2, 3);
}
