#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>

#define min(a, b) ( a< b ? a : b)
#define max(a, b) (a > b ? a : b)

using namespace std;

short reachable[110][10010];
int a[10010];
int N, K, tmp;

inline int mod(int x, int kk)
{
	if (x < 0)
	{
		while (x < 0)
			x += kk;
	}
	else
	{
		x %= kk;
	}
	
	return x;
}

int main()
{
	memset(reachable, 0, sizeof(reachable));
	memset(a, 0, sizeof(a));

	scanf("%d %d", &N, &K);
	for (int i = 0; i < N; ++i)
	{
		scanf("%d", &a[i]);
	}
	
	reachable[mod(a[0], K)][0] = 1;
	for (int i = 1; i < N; ++i)
	{
		for (int s = 0; s < K; ++s)
		{
			if (reachable[s][i - 1])
			{
				tmp = mod(s + a[i], K);
				reachable[tmp][i] = 1;
				
				tmp = mod(s - a[i], K);
				reachable[tmp][i] = 1;
			}
		}
	}

	if (reachable[0][N - 1])
		printf("Divisible\n");
	else
		printf("Not divisible\n");

	return 0;
}
