#include <iostream>
#include <deque>
using namespace std;
struct STATE
{
	int r, c, cha, dist;
	STATE() {}
	STATE(int r_, int c_, int cha_, int dist_) : r(r_), c(c_), cha(cha_), dist(dist_) {}
};
char Map[210][210];
bool visit[210][210][15];
int dr[4] = { 1, -1, 0, 0 }, dc[4] = { 0, 0, 1, -1 };
int main()
{
	cin.sync_with_stdio(false);
	int m, n, k;
	cin >> m >> n >> k;
	STATE root;
	int target_r, target_c;
	for (int i = 0; i < m; ++i)
		for (int j = 0; j < n; ++j)
		{
			cin >> Map[i][j];
			if (Map[i][j] == '@')
			{
				root.r = i;
				root.c = j;
				root.cha = k;
				root.dist = 0;
			}
			if (Map[i][j] == '+')
			{
				target_r = i;
				target_c = j;
			}
		}
	deque<STATE> q;
	q.push_back(root);
	visit[root.r][root.c][root.cha] = true;
	while (!q.empty())
	{
		STATE here = q.front();
		if (here.r == target_r && here.c == target_c)
			break;
		q.pop_front();
		for (int i = 0; i < 4; ++i)
		{
			int r_ = here.r + dr[i], c_ = here.c + dc[i];
			if (r_ < 0 || r_ >= m || c_ < 0 || c_ >= n)
				continue;
			int cha_ = here.cha;
			if (Map[r_][c_] == '#')
			{
				if (cha_ <= 0) continue;
				else cha_--;
			}
			if (visit[r_][c_][cha_]) continue;
			q.push_back(STATE(r_, c_, cha_, here.dist + 1));
			visit[r_][c_][cha_] = true;
		}
	}
	if (q.empty()) cout << -1;
	else cout << q.front().dist;
	return 0;
}