#include <cstdio>
#include <cstring>
#include <iostream>
#include <cstdlib>

using namespace std;

int n, k, ans;
short vis[15];
char m[15][15];

void dfs(int cur,int num)
{
  if(num==k)
  {
    ++ans;
    return;
  }

  for(int i = cur; i < n; ++i)
    for(int j = 0; j < n; ++j)
      if(m[i][j] == '#' && !vis[j])
      {
        vis[j]=1;
        dfs(i + 1, num + 1);
        vis[j]=0;
      }
}

void work()
{
  memset(vis, 0, sizeof(vis));

  for(int i = 0; i < n; ++i)
    gets(m[i]);
  
  ans=0;
  dfs(0,0);
  
  printf("%d\n",ans);  
}

int main()
{
  while(scanf("%d %d\n", &n, &k) == 2 && n != -1 && k != -1)
    work();

  
  return 0;
}
