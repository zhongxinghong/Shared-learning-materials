#include <iostream>
#include <cstring>

using namespace std;


int m, n, k;
int digitSum[10000];
int f[10000];
int label[10000];
char c;

int main()
{
	memset(digitSum, sizeof(digitSum), 0);
	memset(f, sizeof(f), 0);
	memset(label, sizeof(label), 0);

	cin >> m >> c >> n >> c >> k;

	for (int i = m + 1; i < n; ++i)
	{
		digitSum[i] = i / 1000 + (i % 1000) / 100 + (i % 100) / 10 + i % 10;

		if (digitSum[i] % k == 0)
		{
			f[digitSum[i] / k]++;
			label[i] = digitSum[i] / k;
		}
	}

	for (int i = m + 1; i < n; ++i)
	{
		if (digitSum[i] % k == 0)
		{
			for (int j = i; j < n; ++j)
			{
				if (label[j] == label[i])
				{
					if (f[digitSum[i] / k] < 1)
						continue;

					cout << j;

					f[digitSum[i] / k]--;
					if (f[digitSum[i] / k] > 0)
					{
						cout << ',';
					}
					else
					{
						cout << endl;
					}
				}
			}
		}

	}



	return 0;

}