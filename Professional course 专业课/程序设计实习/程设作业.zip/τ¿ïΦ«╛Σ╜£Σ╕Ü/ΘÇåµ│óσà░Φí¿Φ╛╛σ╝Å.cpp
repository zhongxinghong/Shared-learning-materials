#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

double exp()
{
	char s[100];
	scanf("%s", s);

	switch (s[0])
	{
		case '+' : return (exp() + exp());
		case '-' : return (exp() - exp());
		case '*' : return (exp() * exp());
		case '/' : return (exp() / exp());
		default : return (atof(s));
	}
}

int main()
{
	double ans = exp();
	printf("%f\n", ans);

	return 0;
}
