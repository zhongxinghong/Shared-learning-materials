#include <iostream>
#include <cstring>
using namespace std;
template <int bitNum>
struct MyBitset
{
	char a[bitNum / 8 + 1];
	MyBitset() { memset(a, 0, sizeof(a)); };
	void Set(int i, int v) {
		char & c = a[i / 8];
		int bp = i % 8;
		if (v)
			c |= (1 << bp);
		else
			c &= ~(1 << bp);
	}
	// 在此处补充你的代�?

	class refer
	{
	private:
		char& data;
		int bp;
	public:
		refer(char& c, const int& b) :
			data(c), bp(b)
		{
		}

		refer& operator = (int x)
		{
			if (x)
			{
				data |= (1 << bp);
			}
			else
			{
				data &= ~(1 << bp);
			}

			return *this;
		}

		refer& operator = (const refer& _r)
		{
			int x = ((_r.data >> _r.bp) & 1);
			if (x)
			{
				data |= (1 << bp);
			}
			else
			{
				data &= ~(1 << bp);
			}

			return *this;
		}

		friend ostream& operator << (ostream& o, const refer& xx)
		{
			if ((xx.data >> xx.bp) & 1)
			{
				cout << 1;
			}
			else
			{
				cout << 0;
			}
			return o;
		}
	};

	refer operator [] (int x)
	{
		refer tmp(a[x / 8], x % 8);
		return tmp;
	}

	// ******************
	void Print() {
		for (int i = 0; i < bitNum; ++i)
			cout << (*this)[i];
		cout << endl;
	}

};

int main()
{
	int n;
	int i, j, k, v;
	while (cin >> n) {
		MyBitset<20> bs;
		for (int i = 0; i < n; ++i) {
			int t;
			cin >> t;
			bs.Set(t, 1);
		}
		bs.Print();
		cin >> i >> j >> k >> v;
		bs[k] = v;
		bs[i] = bs[j] = bs[k];
		bs.Print();
		cin >> i >> j >> k >> v;
		bs[k] = v;
		(bs[i] = bs[j]) = bs[k];
		bs.Print();
	}
	return 0;
}
