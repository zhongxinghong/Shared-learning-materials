#include<cstdio>
#include<cstring>
#include<iostream>
#include<set>


using namespace std;

typedef multiset<int> myset;
typedef myset::iterator myi;

myset s;
int n, x;
char cmd[500];
bool rec[500];

int tot(const myset & s, const int& x)
{
	int cnt = 0;
	if (s.find(x) != s.end())
	{
		myi i = s.lower_bound(x);
		for (; i != s.upper_bound(x); i++)
		{
			cnt++;
		}
	}
	return cnt;
}


int main()
{
	memset(rec, 0, sizeof(rec));
	
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%s", cmd);
		
		if (strcmp(cmd, "add") == 0)
		{
			scanf("%d", &x);
			rec[x] = true;
			s.insert(x);
			printf("%d\n", tot(s, x));
		}
		else if (strcmp(cmd, "del") == 0)
		{
			scanf("%d", &x);			
			printf("%d\n", tot(s, x));		
			if (s.find(x) != s.end())
			{
				s.erase(x);
			}
		}
		else if (strcmp(cmd, "ask") == 0)
		{
			scanf("%d", &x);
			if (rec[x])
			{
				printf("1 %d\n", tot(s, x));
			}
			else
			{
				printf("0 %d\n", tot(s, x));
			}
		}
	}
	
	return 0;
}
