#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<map>
#include<iterator>
#include<functional>

using namespace std;

int n, id, power;

int main()
{
		
	typedef map<int, int, less<int> > CSheet;
	CSheet sheet;
	CSheet::const_iterator p1, p2;
	sheet.insert(CSheet::value_type(1000000000, 1));
	
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%d %d", &id, &power);
		printf("%d ", id);
		
		if (sheet.begin() == (p1 = sheet.lower_bound(power)))
		{
			printf("%d\n", (*sheet.begin()).second);
			goto tag;		
		}
		p1--;
		
		if (sheet.end() == (p2 = sheet.upper_bound(power)))
		{
			printf("%d\n", (*sheet.end()).second);
			goto tag;
		}
		
		if (abs((*p1).first - power) <= abs((*p2).first - power))
		{
			printf("%d\n", (*p1).second);
		}
		else
		{
			printf("%d\n", (*p2).second);
		}
		
		tag: sheet.insert(CSheet::value_type(power, id));
	}
	
	
	return 0;
}
