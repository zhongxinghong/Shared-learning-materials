#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<string>
#include<vector>
#include<queue>
#include<stack>

using namespace std;

string str[30];
string cmd;
int argNum[] = {-1,3,2,2,2,3,2,1,0};
int n;
stack<string, vector<string> > obj;
stack<int, vector<int> > st;

void fun1()
{
	int L = atoi(obj.top().c_str()); obj.pop();
	int X = atoi(obj.top().c_str()); obj.pop();	
	string tmp(obj.top(), X, L);
	obj.top() = tmp;
}

bool IfAllNumber(char* s)
{
	for (int i = 0 ; i < strlen(s); ++i)
	{
		if (s[i] < '0' || s[i] > '9')
			return false;
	}
	return true;
}

void fun2()
{
	char s1[100]; char s2[100];
	strcpy(s1, obj.top().c_str()); obj.pop();
	strcpy(s2, obj.top().c_str()); obj.pop();
	
	int x1 = atoi(s1);
	int x2 = atoi(s2);
	
	if (IfAllNumber(s1) && IfAllNumber(s2) && (x1 < 100000 && x1 >= 0) && (x2 < 100000 && x2 >= 0))
	{
		char tmp[100];
		itoa(x1 + x2, tmp, 10);
		obj.push(string(tmp));
	}
	else
	{
		char tmp[100];
		obj.push(string(itoa(x1, tmp, 10)) + string(itoa(x2, tmp, 10)));
	}
}

void fun3()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	int pos = str[N].find(obj.top());
	obj.pop();
	
	char tmp[100];
	if (pos != string::npos)
	{
		obj.push(string(itoa(pos, tmp, 10)));
	}
	else
	{
		obj.push(string(itoa(str[N].size(), tmp, 10)));
	}
}

void fun4()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	int pos = str[N].rfind(obj.top());
	obj.pop();
	
	char tmp[100];
	if (pos != string::npos)
	{
		obj.push(string(itoa(pos, tmp, 10)));
	}
	else
	{
		obj.push(string(itoa(str[N].size(), tmp, 10)));
	}
}

void fun5()
{
	int X = atoi(obj.top().c_str()); obj.pop();
	int N = atoi(obj.top().c_str()); obj.pop();
	str[N].insert(X, obj.top());
	obj.pop();
}

void fun6()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	str[N] = obj.top();
	obj.pop();	
}

void fun7()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	cout << str[N] << endl;
}

void fun8()
{
	for (int i = 1; i <= n; ++i)
	{
		cout << str[i] << endl;
	}
}

int main()
{
	scanf("%d", &n);
	for (int i = 1 ; i <= n; ++ i)
	{
		cin >> str[i];
	}
	
	void (*func[9])() = {NULL, fun1, fun2, fun3, fun4, fun5, fun6, fun7, fun8}; 
	
	cin >> cmd;
	while (cmd != "over")
	{
		int opID = -1;
		if (cmd == "copy")
		{
			opID = 1; st.push(opID);
		}
		else if (cmd == "add")
		{
			opID = 2; st.push(opID);
		}
		else if (cmd == "find")
		{
			opID = 3; st.push(opID); 
		}
		else if (cmd == "rfind")
		{
			opID = 4; st.push(opID);
		}
		else if (cmd == "insert")
		{
			opID = 5; st.push(opID);
		}
		else if (cmd == "reset")
		{
			opID = 6; st.push(opID);
		}
		else if (cmd == "print")
		{
			opID = 7; st.push(opID);
		}
		else if (cmd == "printall")
		{
			opID = 8; st.push(opID);
		}
		else
		{
			obj.push(cmd);
			if (obj.size() == argNum[st.top()])
			{
				func[st.top()]();
				
				if (st.top() > 5)
				{
					while (!obj.empty())
					{
						obj.pop();
					}
				}
			}
			st.pop();			
		}		

	}
	
	return 0;
}
