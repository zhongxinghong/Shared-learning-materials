#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<set>
#include<map>
#include<iterator>
#include<functional>

using namespace std;

typedef set<int, less<int> > CRecord;
typedef map<int, CRecord, less<int> > CSheet;
int n, power, id;
CSheet sheet; CSheet::const_iterator p0, p1, p2;
CRecord tmp;

void ins(CSheet& sheet,const int pow, int i)
{
	CSheet::iterator p = sheet.find(pow);
	if (p != sheet.end())
	{
		((*p).second).insert(i);
	}
	else
	{
		CRecord tmp; tmp.insert(i);
		sheet.insert(CSheet::value_type(pow, tmp));
	}
}

int main()
{
		
	tmp.insert(1);
	sheet.insert(CSheet::value_type(1000000000, tmp));

	
	scanf("%d", &n);
	
	for (int i = 1; i <= n; ++i)
	{
		scanf("%d %d", &id, &power);
		
		p0 = sheet.find(power);
		p1 = sheet.lower_bound(power);
		p2 = sheet.upper_bound(power);
		
		if (p0 != sheet.end())
		{
			printf("%d %d\n", id, *((*p0).second.begin()));
			goto tag;
		}
		
		if (p1 == sheet.begin())
		{
			printf("%d %d\n", id, *((*p1).second.begin()));
			goto tag;
		}
		
		if (p2 == sheet.end())
		{
			printf("%d %d\n", id, *((*p2).second.begin()));
			goto tag;		
		}
		
		p1--;
		if (abs((*p1).first - power) == abs((*p2).first - power))
		{
			printf("%d %d\n", id, min(*((*p1).second.begin()),*((*p2).second.begin())) );
			goto tag;
		}
		
		if (abs((*p1).first - power) > abs((*p2).first - power))
		{
			printf("%d %d\n", id, *((*p2).second.begin()));
		}
		else
		{
			printf("%d %d\n", id, *((*p1).second.begin()));			
		}
		
		tag: ins(sheet, power, id);
	}
	
	return 0;
}
