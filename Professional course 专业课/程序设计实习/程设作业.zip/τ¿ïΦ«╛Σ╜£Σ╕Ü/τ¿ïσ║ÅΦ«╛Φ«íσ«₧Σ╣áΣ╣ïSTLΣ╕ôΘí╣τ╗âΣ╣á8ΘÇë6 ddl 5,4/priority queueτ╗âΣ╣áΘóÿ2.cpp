#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<set>
#include<functional>

using namespace std;

#define maxsize 10000000 
bool f[maxsize];
int sigma[maxsize];

inline void preprocess()
{
	memset(f, false, sizeof(f));
	for (int i = 2; i < maxsize; ++i)
	{
		if (!f[i])
		{
			for (int j = 2 * i; j < maxsize; j += i)
			{
				f[j] = true;
			}
		}
	}
	
	memset(sigma, 0 , sizeof(sigma));
	for (int i = 2; i < maxsize; ++i)
	{
		if (!f[i])
		{
			for (int j = 2 * i; j < maxsize; j += i)
			{
				++sigma[j];
			}				
		}

	}
}

struct cmp
{
	bool operator () (const int& x, const int & y) const
	{
		int s1 = sigma[x]; int s2 = sigma[y];
		if (s1 > s2)
			return true;
		if (s1 == s2 && x > y)
			return true;
		return false;
	}
};

typedef multiset<int, cmp> myset;

myset s;
myset::iterator p1, p2;
int n, tmp;

int main()
{
	preprocess();

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= 10; ++j)
		{
			scanf("%d", &tmp);
			s.insert(tmp);
		}
		p1 = s.begin(); p2 = s.end(); p2--;
		printf("%d %d\n", *p1, *p2);
		s.erase(p1); s.erase(p2);
	}

	return 0;
}
