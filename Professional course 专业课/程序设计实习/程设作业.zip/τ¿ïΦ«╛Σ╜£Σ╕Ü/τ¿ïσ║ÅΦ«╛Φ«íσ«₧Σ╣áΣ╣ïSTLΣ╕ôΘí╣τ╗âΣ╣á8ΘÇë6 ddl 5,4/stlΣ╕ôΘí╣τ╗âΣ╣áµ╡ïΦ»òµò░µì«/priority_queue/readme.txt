Time Limit: 2500MS 
Memory Limit: 131072K
Special Judge: NO

