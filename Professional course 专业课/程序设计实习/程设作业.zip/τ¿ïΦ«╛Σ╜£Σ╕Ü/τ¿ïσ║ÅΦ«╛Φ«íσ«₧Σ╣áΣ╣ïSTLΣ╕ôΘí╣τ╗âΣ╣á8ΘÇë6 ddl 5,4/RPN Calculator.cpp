#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<iterator>
#include<vector>
#include<stack>
#include<queue>
#include<functional>

using namespace std;

int main()
{
	int n;
	scanf("%d", &n);

	priority_queue<double, deque<double>, greater<double> > prior;
	for (int i = 1; i <= n; ++i)
	{
		double tmp;
		scanf("%lf", &tmp);
		prior.push(tmp);
	}

	stack<double, vector<double> > st;

	char buf[100];
	char line[500];
	scanf("\n");
	while (scanf("%s", buf) != EOF)
	{
		if (0 == strcmp(buf, "="))
		{
			printf("%e\n", st.top());
			prior.pop();
			prior.push(st.top());
			while (!st.empty())
			{
				st.pop();
			}
		}
		else if (0 == strcmp(buf, "+"))
		{
			double tmp = st.top();
			st.pop();
			st.top() += tmp;
		}
		else if (0 == strcmp(buf, "-"))
		{
			double tmp = st.top();
			st.pop();
			st.top() -= tmp;
		}
		else if (0 == strcmp(buf, "*"))
		{
			double tmp = st.top();
			st.pop();
			st.top() *= tmp;
		}
		else if (0 == strcmp(buf, "/"))
		{
			double tmp = st.top();
			st.pop();
			st.top() /= tmp;
		}
		else if (0 == strcmp(buf, "^"))
		{
			double tmp = st.top();
			st.pop();
			st.top() = pow(st.top(), tmp);
		}
		else
		{
			st.push(atof(buf));
		}
	}


	printf("\n");
	int counter = 0;
	while (!prior.empty())
	{
		printf("%e", prior.top());
		prior.pop();
		++counter;
		if (counter % 10 == 0)
		{
			printf("\n");
		}
		else if (!prior.empty())
		{
			printf(" ");
		}
	}

	return 0;
}
