#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<list>
#include<functional>

using namespace std;

int main()
{
	list<int> *p[10010];
	memset(p, 0, sizeof(p));
	int n, id, id1, id2, num;
	char cmd[100];
	
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%s", cmd);
		if (strcmp(cmd, "new") == 0)
		{
			scanf("%d", &id);
			p[id] = new (list<int>);
		}
		else if (strcmp(cmd, "add") == 0)
		{
			scanf("%d %d", &id, &num);
			if (p[id])
			{
				(*p[id]).push_back(num);
			}
		}
		else if (strcmp(cmd, "merge") == 0)
		{
			scanf("%d %d", &id1, &id2);
			if (p[id1] != NULL && p[id2] != NULL)
			{
				(*p[id1]).merge(*p[id2]);
			}
		}
		else if (strcmp(cmd, "unique") == 0)
		{
			scanf("%d", &id);
			if (p[id])
			{
				(*p[id]).sort();
				((*p[id]).unique());
			}
		}
		else if (strcmp(cmd, "out") == 0)
		{
			scanf("%d", &id);
			if (p[id])
			{
				(*p[id]).sort();
				int cnt = 0;
				for (list<int>::const_iterator i = (*p[id]).begin(); i != (*p[id]).end(); i++)
				{
					++cnt;
					printf("%d", *i);
					if (cnt != (*p[id]).size())
					{
						printf(" ");
					}
				}
				printf("\n");
			}
		}
	}
	
	
	return 0;
}
