#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<string>
#include<vector>
#include<queue>
#include<stack>

using namespace std;

string str[30];
string cmd;
int argNum[] = { -1,3,2,2,2,3,2,1,0 };
int n;
stack<string, vector<string> > obj;
stack<int, vector<int> > st;

char* myitoa(int x, char* dest, int base)
{
	int tmp[100];
	int len = 0;
	while (x > 0)
	{
		tmp[len] = x % 10;
		x /= 10;
		++len;
	}

	for (int i = 0; i < len; ++i)
	{
		dest[i] = '0' + tmp[len - 1 - i];
	}
	dest[len] = '\0';
	return dest;
}

void fun1()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	int X = atoi(obj.top().c_str()); obj.pop();
	int L = atoi(obj.top().c_str()); obj.pop();
	string tmp(str[N], X, L);
	obj.push(tmp);
}

bool IfAllNumber(char* s)
{
	for (int i = 0; i < strlen(s); ++i)
	{
		if (s[i] < '0' || s[i] > '9')
			return false;
	}
	return true;
}

void fun2()
{
	char s1[100]; char s2[100];
	strcpy(s1, obj.top().c_str()); obj.pop();
	strcpy(s2, obj.top().c_str()); obj.pop();

	int x1 = atoi(s1);
	int x2 = atoi(s2);

	if (IfAllNumber(s1) && IfAllNumber(s2) && (x1 < 100000 && x1 >= 0) && (x2 < 100000 && x2 >= 0))
	{
		char tmp[100];
		myitoa(x1 + x2, tmp, 10);
		obj.push(string(tmp));
	}
	else
	{
		char tmp[100];
		obj.push(string(s1) + string(s2));
	}
}

void fun3()
{
	string S = obj.top(); obj.pop();
	int N = atoi(obj.top().c_str()); obj.pop();
	int pos = str[N].find(S);

	char tmp[100];
	if (pos != string::npos)
	{
		obj.push(string(myitoa(pos, tmp, 10)));
	}
	else
	{
		obj.push(string(myitoa(str[N].size(), tmp, 10)));
	}
}

void fun4()
{
	string S = obj.top(); obj.pop();
	int N = atoi(obj.top().c_str()); obj.pop();
	int pos = str[N].rfind(S);

	char tmp[100];
	if (pos != string::npos)
	{
		obj.push(string(myitoa(pos, tmp, 10)));
	}
	else
	{
		obj.push(string(myitoa(str[N].size(), tmp, 10)));
	}
}

void fun5()
{
	string S = obj.top(); obj.pop();
	int N = atoi(obj.top().c_str()); obj.pop();
	int X = atoi(obj.top().c_str()); obj.pop();
	str[N].insert(X, S);
}

void fun6()
{
	string S = obj.top(); obj.pop();
	int N = atoi(obj.top().c_str()); obj.pop();
	str[N] = S;
}

void fun7()
{
	int N = atoi(obj.top().c_str()); obj.pop();
	cout << str[N] << endl;
}

void fun8()
{
	for (int i = 1; i <= n; ++i)
	{
		cout << str[i] << endl;
	}
}

int main()
{

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		cin >> str[i];
	}

	void(*func[9])() = { NULL, fun1, fun2, fun3, fun4, fun5, fun6, fun7, fun8 };

	char buf[500];
	scanf("\n");
	string cmd;
	while (cin.getline(buf, 490) && (strcmp(buf, "over") != 0))
	{
		int i = strlen(buf) - 1;
		int len0 = i;
		while (buf[0] != '\0')
		{
			for (; buf[i] != ' ' && i >= 0; i--);
			if (i > 0)
			{
				cmd.assign(buf, i + 1, len0);
				buf[i] = '\0';
				--i;
				len0 = i;
			}
			else
			{
				cmd.assign(buf, i + 1, len0 + 1);
				buf[0] = '\0';
			}

			if (cmd == "copy")
			{
				fun1();
			}
			else if (cmd == "add")
			{
				fun2();
			}
			else if (cmd == "find")
			{
				fun3();
			}
			else if (cmd == "rfind")
			{
				fun4();
			}
			else if (cmd == "insert")
			{
				fun5();
				while (!obj.empty())
				{
					obj.pop();
				}
			}
			else if (cmd == "reset")
			{
				fun6();
				while (!obj.empty())
				{
					obj.pop();
				}
			}
			else if (cmd == "print")
			{
				fun7();
				while (!obj.empty())
				{
					obj.pop();
				}
			}
			else if (cmd == "printall")
			{
				fun8();
				while (!obj.empty())
				{
					obj.pop();
				}
			}
			else
			{
				obj.push(cmd);
			}
		}
	}


	return 0;
}
