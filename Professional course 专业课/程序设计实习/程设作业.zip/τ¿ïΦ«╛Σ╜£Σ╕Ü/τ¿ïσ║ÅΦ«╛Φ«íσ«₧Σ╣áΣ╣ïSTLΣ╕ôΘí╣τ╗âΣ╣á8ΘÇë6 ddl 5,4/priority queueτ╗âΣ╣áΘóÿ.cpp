#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<set>
#include<functional>

using namespace std;

bool f[10000000];

inline void preprocess()
{
	memset(f, false, sizeof(f));
	for (int i = 2; i < 10000000; ++i)
	{
		if (!f[i])
		{
			for (int j = 2 * i; j < 10000000; j += i)
			{
				f[j] = true;
			}
		}
	}
}

inline int sigma(int x)
{
	int i;
	int tot = 0;
	
	if (!f[x]) return 0;
	
	while (x > 1)
	{

		for (i = 2; i <= x; ++i)
		{
			if (x % i == 0 && (!f[i]))
				break;
		}

		++tot;
		while (x % i == 0)
		{
			x /= i;
		}
	}

	return tot;
}

struct cmp
{
	bool operator () (const int& x, const int & y) const
	{
		int s1 = sigma(x); int s2 = sigma(y);
		if (s1 > s2)
			return true;
		if (s1 == s2 && x > y)
			return true;
		return false;
	}
};

typedef multiset<int, cmp> myset;

myset s;
myset::iterator p1, p2;
int n, tmp;

int main()
{
	preprocess();

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= 10; ++j)
		{
			scanf("%d", &tmp);
			s.insert(tmp);
		}
		p1 = s.begin(); p2 = s.end(); p2--;
		printf("%d %d\n", *p1, *p2);
		s.erase(p1); s.erase(p2);
	}

	return 0;
}
