#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>

#define max(a, b) (a >b ? a : b)

using namespace std;

int m[110], p[110], f[110];
int k, n;

inline int Inf(int i)
{
	int tmp = m[i] - k;
	int j = i - 1;
	while (m[j] >= tmp && j >= 0)
		--j;
	
	return j;
}

inline void work()
{
	memset(m, 0, sizeof(m));
	memset(p, 0, sizeof(p));
	memset(f, 0, sizeof(f));

	scanf("%d %d", &n, &k);
	for (int i = 0; i < n; ++i)
		scanf("%d", &m[i]);
	for (int i = 0; i < n; ++i)
		scanf("%d", &p[i]);
	
	f[0] = p[0];
	for (int i = 1; i <n; ++i)
	{
		int tmpI = Inf(i);
		int tmpAns = p[i];
		if (tmpI >= 0)
			tmpAns = max(tmpAns, f[tmpI] + p[i]);
		for (int j = tmpI + 1; j < i; ++j)
			tmpAns = max(tmpAns, f[j]);

		f[i] = tmpAns;
	}

	printf("%d\n", f[n - 1]);

}

int main()
{
	int T;
	scanf("%d", &T);

	while (T--)
	{
		work();
	}
}
