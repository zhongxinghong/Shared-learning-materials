#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

int a[100001], f[100001];
int t, n;

void work()
{
	scanf("%d\n", &n);
	memset(a, 0, sizeof(a));
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	
	if (1 == n)
	{
		printf("%d", a[1]);
		return;
	}
	
	if (2 == n)
	{
		printf("%d\n", max(a[1], a[2]));
		return;
	}
	
	f[1] = a[1]; f[2] = a[2];
	for (int i = 3; i <= n; i++)
	{
		int maxn = f[i - 1];
		for (int k = 1; k < i - 1; k++)
		{
			maxn = max(maxn, f[k] + a[i]);
		}
		f[i] = maxn;
	}
	printf("%d\n", f[n]);
	
}

int  main()
{
	scanf("%d", &t);
	for (int i = 0; i < t; i++)
	{
		work();
	}
	
	return 0;
}
