#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

int dx[3] = {-1, 0, 1};
int dy[3] = { 0, 1, 0};

int n, cnt;
int vis[50][50];

void DFS(int y, int x, int dep)
{
	vis[y][x] = 1;

	if (dep <= 0)
	{
		++cnt;
	}
	else
	{
		for (int d = 0; d < 3; ++d)
		{
			int ny = y + dy[d];
			int nx = x + dx[d];
			
			if (!vis[ny][nx])
			{
				DFS(ny, nx, dep - 1);
			}
		}
	}

	vis[y][x] = 0;
}

int main()
{
	cin >> n;
	cnt = 0;
	memset(vis, 0, sizeof(vis));

	DFS(0, 20, n);

	cout << cnt;

	return 0;
}
