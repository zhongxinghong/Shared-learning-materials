#include <iostream>
#include <memory.h>
#include <climits>

using namespace std;

#define min(a, b) a < b ? a: b

int f[17][150000];
int a[17][17];
int n;

void dp(int src, unsigned int S)
{
	if (f[src][S] != -1)
	{
		return;
	}
	else if (S == 0)
	{
		f[src][S] = a[src][n];
		return;
	}
	else
	{
		f[src][S] = INT_MAX;
		for (int i = 2; i < n; ++i)
		{
			if (S & (1 << i))
			{
				dp(i, S ^ (1 << i));
				f[src][S] = min(f[src][S], f[i][S ^ (1 << i)] + a[src][i]);
			}
		}
	}
}

int main()
{
	cin >> n;
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			cin >> a[i][j];
		}
	}

	memset(f, -1, sizeof(f));
	dp(1, (1 << n) - 4);

	cout << f[1][(1 << n) - 4];

	return 0;
}
