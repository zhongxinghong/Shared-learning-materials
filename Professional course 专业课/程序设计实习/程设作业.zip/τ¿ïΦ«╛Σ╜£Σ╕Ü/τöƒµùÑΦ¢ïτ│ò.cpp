#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <iostream>

#define MAXN 2147483647

using namespace std;

int fu, n, mins, i, j, k, a[30][3], s, v;

int dfs(const int & m, const int & r, int h, int s, int v)  
{  
    int i, j, k, ca, tmp;

    v += r * r * h;
    s += 2 * r * h;
    if(v > n)
        return 1;  
    if(s + 2 * (n - v) / r >= mins)
        return 2;
        
    if(m == fu)  
    {  
        if(v < n)
        {
            return -1;
        }
        else
        {
            if(v > n)
                return 1;
        }

        if(mins > s)
        {
            mins = s;
        }
        return 0;
    }
    else
    {
        if(v >= n)
            return 1;
    }

    if(m < fu)
    {  
        ca = dfs(m + 1, r - 1, h - 1, s, v);
        if(ca == -1)
            return -1;
        else
        {
            if(ca == 0)  
                return 0;
        }
        
        ca = dfs(m + 1, fu - m, fu - m, s, v);
        if(ca == 1)  
            return 1;
        else
        {
            if(ca == 0)
                return 0;
        }
    }

    for(i = r - 1; i >= fu - m; i--)
    {
        tmp = (n-v) / (i * i);
        for(j = min(tmp, h - 1); j >= fu - m; j--)
        {
            if(j != h - 1 || i != r - 1)
                if(j != fu - m || i != fu - m)
                    dfs(m + 1, i, j, s, v);
        }
    }

    return 2;  
}

void work()
{
    mins = MAXN; k = 0; v = 0;    
    memset(a, sizeof(a), 0);
    a[0][0] = sqrt((double)n);

    for(int i = a[0][0]; i >= fu; --i)
    {
        s = i * i;
        for(j = n / (i * i); j >= fu; --j)
            dfs(1, i, j, s, v);
    }

    if(mins != MAXN)
        printf("%d\n", mins);  
    else
        printf("0\n");
} 

int main()
{
    while(scanf("%d %d", &n, &fu) == 2)
        work();
 
    return 0;
}
