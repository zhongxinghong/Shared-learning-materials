#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

struct searchNode
{
    int x,y,pre;
};

int dx[4]={1,-1,0,0}, dy[4]={0,0,-1,1};
int M[5][5];
searchNode q[100];
int front=0,rear=1;

void printRoute(int i)
{
    if(q[i].pre!=-1)
    {
        printRoute(q[i].pre);
        printf("(%d, %d)\n", q[i].x, q[i].y);
    }
}

void bfs(int x0,int y0)
{
    q[front].x = x0;
    q[front].y = y0;
    q[front].pre = -1;

    while(front < rear)
    {
        for(int i = 0; i < 4; ++i)
        {
            int nx = q[front].x + dx[i];
            int ny = q[front].y + dy[i];
            if(nx < 0 || nx > 4 || ny < 0 || ny > 4 || M[nx][ny])
                continue;

            M[nx][ny] = 1;
            q[rear].x = nx;
            q[rear].y = ny;
            q[rear].pre = front;
            rear++;
            
            if(nx == 4 && ny == 4)
                printRoute(front); 
        }

        front++;
    }
}

int main()
{
    for(int i = 0; i < 5; i++)
        for(int j = 0; j < 5; j++)
            scanf("%d", &M[i][j]);
            
	printf("(0, 0)\n");
    bfs(0, 0);    
	printf("(4, 4)\n");

    return 0;
}
