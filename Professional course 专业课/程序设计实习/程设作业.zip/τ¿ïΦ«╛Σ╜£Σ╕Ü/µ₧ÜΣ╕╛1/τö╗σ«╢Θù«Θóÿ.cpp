#include<iostream>
#include<cstdio>
#include<climits>
#include<cstring>
#include<cstdlib>

using namespace std;

int n, PaintCount;
int p = -1;
short a[20][20], b[20][20];
char tmp;

inline bool Completed()
{
	for (int i = 1; i <= n; ++i)
	{
		if (!b[n][i])
			return false;
	}
	return true;
}

inline void Paint(int i, int j)
{
	b[i][j] = (b[i][j] + 1) % 2;
	b[i - 1][j] = (b[i - 1][j] + 1) % 2;
	b[i][j - 1] = (b[i][j - 1] + 1) % 2;
	b[i][j + 1] = (b[i][j + 1] + 1) % 2;
	b[i + 1][j] = (b[i + 1][j] + 1) % 2;
}

bool generateP()
{
	++p;
	PaintCount = 0;
	if (p < (1 << n))
	{
		for (int j = 0; j < n; ++j)
		{
			if (((1 << j) & p) > 0)
			{
				Paint(1, j + 1);
				++PaintCount;
			}
		}
		return true;
	}
	else
	{
		return false;
	}
}

int main()
{
	memset(a, 0, sizeof(a));
	memset(b, 0, sizeof(b));

	cin >> n;
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			cin >> tmp;
			if (tmp == 'w')
			{
				a[i][j] = 0;
			}
			else if (tmp == 'y')
			{
				a[i][j] = 1;
			}
		}
	}

	int minCount = INT_MAX;
	memcpy(b, a, sizeof(a));
	while (generateP())
	{
		for (int i = 2; i <= n; ++i)
		{
			for (int j = 1; j <= n; ++j)
			{
				if (!b[i - 1][j])
				{
					++PaintCount;
					Paint(i, j);
				}
			}
		}

		if (Completed())
		{
			if (PaintCount < minCount)
			{
				minCount = PaintCount;
			}
		}

		memcpy(b, a, sizeof(a));
	}

	if (minCount < INT_MAX)
	{
		printf("%d", minCount);
	}
	else
	{
		printf("inf");
	}

	return 0;
}
