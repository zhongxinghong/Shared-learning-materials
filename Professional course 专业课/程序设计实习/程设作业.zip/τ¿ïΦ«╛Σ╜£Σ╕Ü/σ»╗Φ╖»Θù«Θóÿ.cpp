#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

#define min(a, b) (a < b ? a : b)

using namespace std;

struct road
{
	int dest, l, t;
};

road cityMap[110][10001];
short vis[110] = { 0 };
int totEdge[110] = { 0 };
unsigned int midL[110][10001];
int totLen, minLen, cost;
int N, K, R;

void DFS(int s)
{
	if (totLen >= midL[s][cost] || totLen >= minLen || cost > K)
		return;

	midL[s][cost] = totLen;

	if (s == N)
	{
		minLen = min(minLen, totLen);
		return;
	}

	for (int i = 0; i < totEdge[s]; ++i)
	{
		const road & rr = cityMap[s][i];
		if (!vis[rr.dest])
		{
			cost += rr.t;
			totLen += rr.l;
			vis[rr.dest] = 1;

			DFS(rr.dest);

			vis[rr.dest] = 0;
			cost -= rr.t;
			totLen -= rr.l;
		}
	}
}

int main()
{
	memset(midL, 0xFFFFFFFF, sizeof(midL));
	memset(vis, 0, sizeof(vis));
	totLen = 0;
	cost = 0;
	minLen = INT_MAX;

	scanf("%d%d%d", &K, &N, &R);
	for (int i = 0; i < R; ++i)
	{
		int src;
		road r;
		scanf("%d%d%d%d", &src, &r.dest, &r.l, &r.t);
		if (src != r.dest)
		{
			cityMap[src][totEdge[src]++] = r;
		}
	}

	vis[1] = 1;
	DFS(1);

	if (minLen < INT_MAX)
	{
		printf("%d\n", minLen);
	}
	else
	{
		printf("-1\n");
	}


	return 0;
}
