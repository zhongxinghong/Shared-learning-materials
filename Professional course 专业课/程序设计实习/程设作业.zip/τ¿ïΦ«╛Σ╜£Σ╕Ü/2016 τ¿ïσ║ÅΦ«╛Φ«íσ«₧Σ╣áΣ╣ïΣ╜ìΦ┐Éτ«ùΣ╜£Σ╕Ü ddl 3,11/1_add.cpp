#include<cstdio>
#include<cstdlib>

using namespace std;

int main(int argc, char* argv[])
{
	int a, b;
	a = atoi(argv[1]);
	b = atoi(argv[argc - 1]);
	printf("%d\n", a + b);
	return 0;
}
