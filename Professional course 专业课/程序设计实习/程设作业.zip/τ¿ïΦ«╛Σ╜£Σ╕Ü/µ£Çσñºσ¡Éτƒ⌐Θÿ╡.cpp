#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>

#define max(a, b) (a > b ? a : b)

using namespace std;

int a[105][105];
int s[105][105];
int maxSum;
int n;

int main()
{
	memset(a, 0, sizeof(a));
	memset(s, 0, sizeof(s));

	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			scanf("%d", &a[i][j]);
		}
	}

	s[1][1] = a[1][1];
	for (int i = 1; i <= n; ++i)
	{
		s[1][i] = s[1][i - 1] + a[1][i];
		s[i][1] = s[i - 1][1] + a[i][1];
	};
	for (int i = 2; i <= n; ++i)
	{
		for (int j = 2; j <= n; ++j)
		{
			s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + a[i][j];
		}
	}

	int maxSum = INT_MIN;
	for (int r1 = 1; r1 <= n; ++r1)
	{
		for (int c1 = 1; c1 <= n; ++c1)
		{
			for (int r2 = r1; r2 <= n; ++r2)
			{
				for (int c2 = c1; c2 <= n; ++c2)
				{
					int tmpS = s[r2][c2] - s[r2][c1 - 1] - s[r1 -1][c2] + s[r1 - 1][c1 - 1];
					maxSum = max(maxSum, tmpS);
				}
			}
		}
	}

	printf("%d\n", maxSum);

	return 0;
}
