#include <cstdio>
#include <iostream>

using namespace std;

int n, k;

int DFS1(int rest, int minx, int num)
{
	if (num == 0 && rest == 0)
		return 1;
	
	if (num == 0 && rest > 0)
		return 0;
		
	if (num == 1 && rest >= minx)
		return 1;

	int ans = 0;
	for (int i = minx; i <= rest - minx; ++i)
	{
		ans += DFS1(rest - i, i, num - 1);
	}

	return ans;
}

int DFS2(int res, int minx)
{
	if (res == 0)
		return 1;

	if (res <= minx)
		return 0;
	if (res <= 2 * minx)
		return 1;


	int ans = 0;
	for (int i = minx + 1; i <= res; ++i)
	{
		ans += DFS2(res - i, i);
	}

	return ans;
}

int DFS3(int res, int minx)
{
	if (res == 0)
		return 1;

	if (res < minx)
		return 0;

	if (res < 2 * minx)
		return 1;


	int ans = 0;
	for (int i = minx; i <= res; i += 2)
	{
		ans += DFS3(res - i, i);
	}

	return ans;	
}

int work()
{

	int ans1 = 0;
	for (int i = 1; i <= n; ++i)
		ans1 += DFS1(n - i, i, k - 1);
	printf("%d\n", ans1);

	int ans2 = 0;
	for (int i = 1; i <= n; ++i)
		ans2 += DFS2(n - i, i);
	printf("%d\n", ans2);

	int ans3 = 0;
	for (int i = 1; i <= n; i+=2)
		ans3 += DFS3(n - i, i);

	printf("%d\n", ans3);

}

int main()
{
	while (	scanf("%d %d", &n, &k) != EOF)
		work();
		
	return 0;
}
