#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int n, totlen;
char s[10000][256];

int comPrefix(char * a, char * b)
{
	int i = 0;
	for (; i < strlen(a) && i < strlen(b); ++i)
	{
		if (a[i] != b[i])
		{
			break;
		}
	}
	return i;
}

int main()
{
	scanf("%d", &n);
	totlen = 0;

	for (int i = 0; i < n; ++i)
	{
		scanf("%s", s[i]);
		totlen += strlen(s[i]);
	}

	
	for (int i = 1; i < n; ++i)
	{
		++totlen;
		totlen -= comPrefix(s[i - 1], s[i]);

	}

	cout << totlen;

	return 0;
}
