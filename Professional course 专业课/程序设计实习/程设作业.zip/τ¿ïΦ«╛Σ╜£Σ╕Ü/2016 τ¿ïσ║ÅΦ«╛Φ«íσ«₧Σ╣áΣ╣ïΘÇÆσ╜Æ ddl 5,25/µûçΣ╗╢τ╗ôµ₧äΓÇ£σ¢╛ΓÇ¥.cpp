#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>

using namespace std;

int n;
char str[60];
string fileList[90][90];
int totFile[90];

inline void PrintTab(int dep)
{
	for (int k = 0; k < dep; ++k)
	{
		printf("|     ");
	};
}

void work()
{
	printf("DATA SET %d:\nROOT\n", n);

	int dep = 0;
	memset(totFile, 0, sizeof(totFile));

	while (str[0] != '*' && str[0] != '#')
	{
		if (str[0] == 'f')
		{
			++totFile[dep];			
			string tmp = str;
			fileList[dep][totFile[dep]] = tmp;

		}
		else if (str[0] == 'd')
		{
			dep++;
			PrintTab(dep);
			printf("%s\n", str);
		}
		else if (str[0] == ']')
		{
			sort(fileList[dep] + 1, fileList[dep] + totFile[dep] + 1);
			for (int i = 1; i <= totFile[dep]; ++i)
			{
				PrintTab(dep);
				cout << fileList[dep][i] << endl;
			}
			
			totFile[dep] = 0;
			--dep;
		}

		cin >> str;
	}

	if (str[0] == '*')
	{
		++n;

		sort(fileList[dep] + 1, fileList[dep] + totFile[dep] + 1);
		for (int i = 1; i <= totFile[dep]; ++i)
		{
			PrintTab(dep);
			cout << fileList[dep][i] << endl;
		}	
		
		totFile[dep] = 0;
	}
}

int main()
{
	
	n = 1;
	cin >> str;
	while (str[0] != '#')
	{
		if (n > 1) cout << endl;
		
		work();
		cin >> str;
	}

	return 0;
}
