#include <iostream>
#include <string>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <cstdlib>
using namespace std;

class Student {
	private:
		char name[1000];
		int age;
		int id;
		int grade[4];
		double ave;
	
	public:	
		void input()
		{
			scanf("%[^,],%d,%d,%d,%d,%d,%d", name, &age, &id, &grade[0], &grade[1], &grade[2], &grade[3]);
 	   }
	
		void calculate()
		{
			ave = (grade[0] + grade[1] + grade[2] + grade[3]) / 4.0;
		}
	
		void output()
		{
			printf("%s,%d,%d,", name, age, id);
			cout << ave;
		}
};

int main() {
	Student student;        // ������Ķ���
	student.input();        // ��������
	student.calculate();    // ����ƽ���ɼ�
	student.output();       // �������
}
