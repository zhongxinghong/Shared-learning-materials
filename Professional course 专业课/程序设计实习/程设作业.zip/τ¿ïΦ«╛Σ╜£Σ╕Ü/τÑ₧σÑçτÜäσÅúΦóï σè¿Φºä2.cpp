#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

int v[100];
int sum[100];
int n;

int main()
{
	memset(v, 0 ,sizeof(v));
	memset(sum, 0 ,sizeof(sum));

	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		cin >> v[i];

		for (int j = 40; j >= 0; --j)
		{
			if (j + v[i] <= 40)
				sum[j + v[i]] += sum[j];
		}
		++sum[v[i]];
	}

	cout << sum[40] << endl;

	return 0;
}
