#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

int coin[210];
int f[10010];
int g[210][10010];

int n, x;

int main()
{
	memset(coin, 0, sizeof(coin));
	memset(f, 0, sizeof(f));
	memset(g, 0, sizeof(g));


	scanf("%d%d", &n, &x);
	for (int i = 0; i < n; ++i)
		scanf("%d", &coin[i]);
	sort(coin, coin + n);

	f[0] = 1;
	for (int i = 0; i < n; ++i)
	{
		for (int s = x; s >= coin[i]; --s)
		{
			f[s] += f[s - coin[i]]; 
		}
	}


	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < coin[i]; ++j)
		{
			g[i][j] = f[j];
		}

		for (int j = coin[i]; j <= x; ++j)
		{
			g[i][j] = f[j] - g[i][j - coin[i]];
		}
	}

	int cnt = 0;
	for (int i = 0; i < n; ++i)
	{
		if (g[i][x] == 0)
			cnt++;
	}
	printf("%d\n", cnt);
	for (int i = 0; i < n; ++i)
	{
		if (g[i][x] == 0)
		{
			printf("%d", coin[i]);
			cnt--;
			if (cnt > 0)
				printf(" ");
		}
	}


	return 0;
}
