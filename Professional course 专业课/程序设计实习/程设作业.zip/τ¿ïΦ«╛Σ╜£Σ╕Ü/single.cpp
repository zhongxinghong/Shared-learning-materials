#include<cstdio>
#include<iostream>
#include<cstdlib>

using namespace std;

class test
{
	private:
		test()
		{
			
		}
		static test* v;
	
	public:
		static test* getv()
		{
			if (v == NULL)
			{
				v = new test();
			}
			return v;
		}
};

int main()
{
}
