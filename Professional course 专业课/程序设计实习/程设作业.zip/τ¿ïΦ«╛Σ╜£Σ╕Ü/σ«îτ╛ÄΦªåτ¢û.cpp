#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <iostream>

using namespace std;

int f[40] = { 0 };
int n;

int main()
{
	f[0] = 1; f[1] = 0; f[2] = 3; f[3] = 0;
	for (int i = 4; i <= 30; ++i)
	{
		if (i % 2 != 0)
		{
			f[i] = 0;	
		}
		else
		{
			f[i] = f[i - 2] * 3 + f[i - 4] * 2;
			
			int j = i -6;
			while (j >= 0)
			{
				f[i] += 2 * f[j];
				j -= 2;
			}
		}
	}

	scanf("%d", &n);
	while (n != -1)
	{
		printf("%d\n", f[n]);
		scanf("%d", &n);
	}


	return 0;
}
