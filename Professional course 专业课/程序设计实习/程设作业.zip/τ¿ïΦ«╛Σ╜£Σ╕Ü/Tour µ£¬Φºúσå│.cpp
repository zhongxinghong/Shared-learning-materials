#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

int n;
double x[60];
double y[60];

inline void work()
{
	memset(x, 0 ,sizeof(x));
	memset(y, 0, sizeof(y));

	double d = 0;

	for (int i = 0; i < n; ++i)
	{
		scanf("%lf%lf", &x[i], &y[i]);
	}

	for (int i = 0; i < n - 1; ++i)
	{
		d += pow( (pow(x[i + 1] - x[i], 2.0) + pow(y[i + 1] - y[i], 2.0)), 0.5);
	}
	d += pow( (pow(x[0] - x[n - 1], 2.0) + pow(y[0] - y[n - 1], 2.0)), 0.5);

	printf("%.2lf\n", d);
}

int main()
{
	while (scanf("%d", &n) != EOF)
	{
		work();
	}


	return 0;
}
