#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

int dy[4] = { -1, 1, 0, 0 };
int dx[4] = { 0, 0, -1, 1 };

char a[210][210];
short vis[210][210] = { 0 };
unsigned int midL[210][210][11];
int M, N, T, sti, stj, edi, edj;
int cost, minSteps;


void DFS(int y, int x, int dep)
{
	if (a[y][x] == '+')
	{
		if (dep < minSteps)
		{
			minSteps = dep;
		}
		return;
	}

	if (dep >= minSteps)
		return;

	if (dep > midL[y][x][cost])
		return;

	midL[y][x][cost] = dep;

	for (int d = 0; d < 4; ++d)
	{
		int ny = y + dy[d];
		int nx = x + dx[d];

		if (ny < 0 || ny >= M || nx < 0 || nx >= N)
			continue;

		if (a[ny][nx] == '#' && !vis[ny][nx])
		{
			if (cost < T)
			{
				vis[ny][nx] = 1;
				++cost;

				DFS(ny, nx, dep + 1);

				vis[ny][nx] = 0;
				--cost;
			}
		}
		else if (!vis[ny][nx])
		{
			vis[ny][nx] = 1;

			DFS(ny, nx, dep + 1);

			vis[ny][nx] = 0;
		}
	}

}



int main()
{
	memset(midL, 0xFFFFFFFF, sizeof(midL));

	scanf("%d %d %d\n", &M, &N, &T);
	for (int i = 0; i < M; ++i)
	{
		for (int j = 0; j < N; ++j)
		{
			scanf("%c", &a[i][j]);
			if ('@' == a[i][j])
			{
				sti = i;
				stj = j;
			}
			else if ('+' == a[i][j])
			{
				edi = i;
				edj = j;
			}
		}
		if (i < M - 1)
			scanf("\n");
	}

	minSteps = INT_MAX;
	cost = 0;

	vis[sti][stj] = 1;
	DFS(sti, stj, 0);

	if (minSteps < INT_MAX)
		printf("%d\n", minSteps);
	else
		printf("-1\n");


	return 0;
}
