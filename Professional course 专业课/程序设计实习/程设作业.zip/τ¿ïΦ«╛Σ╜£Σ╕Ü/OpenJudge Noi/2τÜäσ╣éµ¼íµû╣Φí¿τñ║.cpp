#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

#define maxPow 15;

void func(int x)
{
	if (x < 4)
	{
		if (x == 3)
			printf("2+2(0)");
		if (x == 2)
			printf("2");
		if (x == 1)
			printf("2(0)");
	}
	else
	{
		int cnt = 0;
		for (int i = 0; i < maxPow; ++i)
		{
			if (x & (1 << i))
				++cnt;
		}

		for (int i = maxPow - 1; i >= 0; --i)
		{
			if (x & (1 << i))
			{
				--cnt;
				if (i > 1)
				{
					printf("2(");
					func(i);
					printf(")");
				}
				else if (i == 1)
				{
					printf("2");
				}
				else if (i == 0)
				{
					printf("2(0)");
				}

				if (cnt > 0)
					printf("+");
			}
		}
	}
}

int main()
{
	cin >> n;
	func(n);


	return 0;
}