#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

int f[200] = {0};
int n;

int main()
{
	f[0] = 1; f[1] = 1; f[2] = 2; f[3] = 4;
	for (short i = 4; i <= 100; ++i)
		f[i] = f[i - 1] + f[i - 2] + f[i - 3];

	while (scanf("%d", &n) != EOF && (n != 0))
	{
		printf("%d\n", f[n]);
	}

	return 0;
}