#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

int t, m ,n;

int func(int m, int n)
{
	if (m < n)
		return func(m , m);
	if (m == 0)
		return 1;
	if (n == 1)
		return 1;
	if (n == 0 && m > 0)
		return 0;
	return (func(m - n, n) + func(m, n - 1));
}

int main()
{
	cin >> t;
	while (t--)
	{
		cin >> m >> n;
		cout << func(m, n) << endl;
	}


	return 0;
}
