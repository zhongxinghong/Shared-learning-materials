#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

#define max(a, b) (a > b ? a : b)

using namespace std;

class BigInt
{
public:
	int size;
	int dat[300];

	BigInt()
	{
		size = 0;
		memset(dat, 0, sizeof(dat));
	}

	BigInt(int n)
	{
		if (n == 0)
		{
			memset(dat, 0, sizeof(dat));
			size = 1;
		}
		else
		{
			while (n > 0)
			{
				dat[size] = n % 10;
				n /= 10;
				++size;
			}
		}
	}

	BigInt(const BigInt & tmp)
	{
		memset(dat, 0, sizeof(dat));
		size = tmp.size;
		for (int i = 0; i < size; ++i)
			dat[i] = tmp.dat[i];
	}

	BigInt & operator = (const BigInt & b)
	{
		memset(dat, 0, sizeof(dat));
		size = b.size;
		for (int i = 0; i < size; ++i)
			dat[i] = b.dat[i];
		return *this;
	}

	BigInt operator + (const BigInt & b)
	{
		BigInt tmp(*this);
		int newS = max(b.size, this->size);
		for (int i = 0; i <= newS; ++i)
		{
			tmp.dat[i] += b.dat[i];
		}
		for (int i = 0; i <= newS + 2; ++i)
		{
			tmp.dat[i + 1] += tmp.dat[i] / 10;
			tmp.dat[i] %= 10;
		}

		int i = tmp.size + 2;
		for (; i >= 0; --i)
		{
			if (tmp.dat[i] != 0)
				break;
		}

		tmp.size = i + 1;

		return tmp;
	}

	BigInt operator * (int n)
	{
		BigInt tmp(*this);

		for (int i = 0; i < tmp.size; ++i)
			tmp.dat[i] *= n;
		for (int i = 0; i < tmp.size + 3; ++i)
		{
			tmp.dat[i + 1] += tmp.dat[i] / 10;
			tmp.dat[i] %= 10;
		}

		int i = tmp.size + 2;
		for (; i >= 0; --i)
		{
			if (tmp.dat[i] != 0)
				break;
		}

		tmp.size = i + 1;

		return tmp;
	}

	friend ostream & operator << (ostream & o, const BigInt & x)
	{
		for (int i = x.size - 1; i >= 0; --i)
			printf("%d", x.dat[i]);
		return o;
	}
};

BigInt f[300] = { 1, 1, 3 };
int n;

int main()
{
	for (int i = 3; i <= 250; ++i)
	{
		f[i] = f[i - 1] + f[i - 2] * 2;
	}

	while (scanf("%d", &n) != EOF)
	{
		cout << f[n] << endl;
	}


	return 0;
}

