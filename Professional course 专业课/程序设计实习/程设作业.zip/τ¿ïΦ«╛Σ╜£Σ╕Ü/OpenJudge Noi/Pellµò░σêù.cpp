#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

using namespace std;

int f[1000001];
int n, k;

int main()
{
	f[1] = 1; f[2] = 2;
	for (int i = 3; i < 1000001; ++i)
		f[i] = ((2 * f[i - 1]) % 32767 + f[i - 2] % 32767) % 32767;

	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &k);
		printf("%d\n", f[k]);
	}

	return 0;
}