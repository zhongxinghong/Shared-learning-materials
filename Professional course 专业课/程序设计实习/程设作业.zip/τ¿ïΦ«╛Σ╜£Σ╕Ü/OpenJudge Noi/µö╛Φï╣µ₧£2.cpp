#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cmath>
#include <iostream>

#define MAXN 250

using namespace std;

int m, n, f[300][300];
int t;

void work()
{
	memset(f, 0, sizeof(f));
	cin >> m >> n;

	for (int i = 0; i < MAXN; ++i)
		f[0][i] = 1;
	for (int i = 0; i < MAXN; ++i)
		f[i][1] = 1;

	for (int i = 1; i <= m; ++i)
	{
		for (int j = 2; j <= n; ++j)
		{
			if (i < j)
				f[i][j] = f[i][i];
			else
				f[i][j] = f[i - j][j] + f[i][j - 1];
		}
	}

	cout << f[m][n] << endl;
}

int main()
{
	cin >> t;
	while (t--)
		work();

	return 0;
}
