#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>

#define min(a, b) ( a< b ? a : b)
#define max(a, b) (a > b ? a : b)

using namespace std;

int k, la, lb, ia, ib, fa, fb;
int ans;

inline int mod(int x, int kk)
{
	if (x < 0)
	{
		while (x < 0)
			x += kk;
	}
	else
	{
		x %= kk;
	}

	return x;
}

int gcd(int a, int b)
{
	int tmp;
	if (a < b)
	{
		tmp = a;
		a = b;
		b = tmp;
	}

	if (a % b == 0)
		return b;
	else
		return (gcd(b, a % b));
}

int main()
{
	cin >> k >> la >> lb >> ia >> ib >> fa >> fb;
	int d = gcd(ia, ib);

	if ((fb - fa) % d != 0)
	{
		printf("no answer\n");
		return 0;
	}

	int T = ia * ib / d;
	int x = 0; int y = 0;
	for (x = 0; x < 1000; ++x)
	{
		for (y = 0; y < 1000; ++y)
		{
			if (fa + ia * x == fb + ib * y)
			{
				goto tag;
			}
		}
	}
	tag:

	int passedTime;
	bool hasSolution = false;
	for (int p = 0; p < 1000; ++p)
	{
		passedTime = fa + x * ia + p * T;
		if (mod(la + passedTime, k) == mod(lb - passedTime, k))
		{
			hasSolution = true;
			ans = passedTime;
			break;
		}
	}

	if (hasSolution)
	{
		printf("%d\n", ans);
	}
	else
	{
		printf("no answer\n");
	}


	return 0;
}
