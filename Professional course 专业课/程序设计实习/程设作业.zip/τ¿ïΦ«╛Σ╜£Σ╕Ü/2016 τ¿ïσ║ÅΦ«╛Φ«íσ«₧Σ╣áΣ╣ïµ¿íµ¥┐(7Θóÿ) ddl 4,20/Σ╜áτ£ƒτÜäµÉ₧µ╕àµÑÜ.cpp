#include <iostream>
using namespace std;
class MyCin
{
// 在此处补充你的代码
private:
	bool IfStop;
public:
	MyCin()
	{
		IfStop = false;
	}
	
	MyCin& operator >> (int& x)
	{
		cin >> x;
		if (x == -1)
		{
			IfStop = true;
		}
		return *this;
	}
	
	operator bool()
	{
		return (!IfStop);
	}

//
};
int main()
{
    MyCin m;
    int n1,n2;
    while( m >> n1 >> n2) 
        cout  << n1 << " " << n2 << endl;
    return 0;
}
