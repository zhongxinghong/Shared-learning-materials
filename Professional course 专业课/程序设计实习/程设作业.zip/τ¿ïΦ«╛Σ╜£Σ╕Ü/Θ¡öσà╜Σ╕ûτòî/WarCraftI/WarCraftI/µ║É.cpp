#include<cstdio>
#include<iostream>
#include<cstring>

using namespace std;


class headquarter;
class city;


int  redOrder[5] = { 2,3,4,1,0 };
int blueOrder[5] = { 3,0,1,2,4 };
int HPlist[5];
int minHP;
char* namelist[5] = { "dragon","ninja","iceman","lion","wolf" };

void setHPlist()
{
	minHP = 2147483647;
	for (int i = 0; i <5; i++)
	{
		scanf("%d", &HPlist[i]);
		minHP = (HPlist[i] < minHP) ? HPlist[i] : minHP;
	}
}

class timeclass
{
public:
	int mh, mm;

	timeclass(int h0, int m0 = 0)
	{
		mh = h0;
		mm = m0;
	}

	timeclass& operator ++ (int k)
	{
		mh++;
		return *this;
	}

	void reset()
	{
		mh = 0;
		mm = 0;
	}
};

timeclass MyTime(0);

class weapon
{
	friend class warrior;
};

class warrior
{
protected:
	headquarter* pHead;
	int id, hp, atk, type;
	city* loc;
	weapon* pWeapon[3];

public:


	// 友元类声明区
	friend class headquarter;
	friend class city;
	friend class weapon;
	//

	warrior(headquarter& h, const int& n, const int& t) :
		pHead(&h), id(n), type(t)
	{
		hp = HPlist[type];
	}

	~warrior()
	{
	}

};

class dragon : public warrior
{
public:
	dragon(headquarter& h, const int& n) :
		warrior(h, n, 0)
	{

	}
};

class ninja : public warrior
{
public:
	ninja(headquarter& h, const int& n) :
		warrior(h, n, 1)
	{

	}
};

class iceman : public warrior
{
public:
	iceman(headquarter& h, const int& n) :
		warrior(h, n, 2)
	{

	}
};

class lion : public warrior
{
public:
	lion(headquarter& h, const int& n) :
		warrior(h, n, 3)
	{

	}
};

class wolf : public warrior
{
public:
	wolf(headquarter& h, const int& n) :
		warrior(h, n, 4)
	{

	}
};

class headquarter
{
private:
	bool IfStopMaking;
public:
	// 公有成员变量声明�?
	int color, totEle, numOfWarrior, numOfEnemyInside;
	int numOfType[5];
	warrior* pWarrior[10001];
	char* strcolor;
	short currOrderOfOutputSoldier;
	int* OutputOrder;
	//

	// 友元类声明区
	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;
	friend class city;
	//

	headquarter(const int& x, const int& m) :
		color(x), totEle(m), numOfWarrior(0), numOfEnemyInside(0)
	{
		memset(pWarrior, 0, sizeof(pWarrior));
		memset(numOfType, 0, sizeof(numOfType));
		currOrderOfOutputSoldier = -1;
		numOfWarrior = 0;
		IfStopMaking = false;

		if (color > 0)
		{
			strcolor = "red";
			OutputOrder = redOrder;
		}
		if (color < 0)
		{
			strcolor = "blue";
			OutputOrder = blueOrder;
		}
	}

	bool OutputSoldier(bool testonly = false)
	{
		//  judge if the headquarter can output one soldier
		//  failed
		if (totEle < minHP)
		{
			if (!IfStopMaking)
			{
				IfStopMaking = true;
				printf("%03d %s headquarter stops making warriors\n", MyTime.mh, strcolor);
			}
			return false;
		}

		//  succeed
		if (testonly)
			return true;

		++currOrderOfOutputSoldier;
		currOrderOfOutputSoldier %= 5;
		while (totEle < HPlist[OutputOrder[currOrderOfOutputSoldier % 5]])
		{
			++currOrderOfOutputSoldier;
			currOrderOfOutputSoldier %= 5;
		}

		currOrderOfOutputSoldier %= 5;
		int tmpid = OutputOrder[currOrderOfOutputSoldier % 5];

		totEle -= HPlist[tmpid];

		//  update num info
		pWarrior[++numOfWarrior] = new warrior(*this, numOfWarrior, tmpid);
		++numOfType[tmpid];

		//  output infomation
		printf("%03d %s %s %d born with strength %d,%d %s in %s headquarter\n",
			MyTime.mh, strcolor, namelist[tmpid], numOfWarrior,
			HPlist[tmpid], numOfType[tmpid],
			namelist[tmpid], strcolor);

		return true;
	}
};

class city
{

};

inline void work()
{
	int m;
	scanf("%d", &m);
	setHPlist();
	MyTime.reset();
	headquarter  red(1, m);
	headquarter blue(-1, m);

	bool flag1 = red.OutputSoldier();
	bool flag2 = blue.OutputSoldier();
	while (flag1 || flag2)
	{
		MyTime++;
		flag1 = red.OutputSoldier();
		flag2 = blue.OutputSoldier();
	}
}




int main()
{
	int k;
	scanf("%d", &k);
	for (int i = 1; i <= k; i++)
	{
		printf("Case:%d\n", i);
		work();
	}

	return 0;
}