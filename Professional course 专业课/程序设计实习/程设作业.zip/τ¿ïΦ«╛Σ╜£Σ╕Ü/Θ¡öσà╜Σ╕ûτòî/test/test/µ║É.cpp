#include<cstdio>
#include<iostream>

using namespace std;

class test
{
private:
	int n;
public:
	~test()
	{
		delete this;
	}
};


int main()
{
	test* p = new test;

	return 0;
}