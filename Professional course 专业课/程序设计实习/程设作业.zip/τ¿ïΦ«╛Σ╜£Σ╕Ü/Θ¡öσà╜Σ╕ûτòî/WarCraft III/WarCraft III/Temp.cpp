/*
160316Ver2:改进了Timer类,不再一分钟一分钟的前进，同时删去了不必要的MySort调用,但还是很慢(380ms)
160316Ver3:因为Weapon类的差别很小,决定不写派生类,重写了Weapon类,另外做了一些代码合并,但还是很慢(320ms)
160316Ver3.1:修改了一点变量名
160316Ver4:0表示红,1表示蓝,-1表示白; 0-4分别表示dragon, ninja, iceman, lion, wolf,输入输出改用stdin/stdout,运行时间显著提升(40ms)
*/
#include "cstdio"
#include "cstring"
#include "algorithm"
using namespace std;

/*游戏中对象的集体声明*/
class TimeClicker;
class Warrior;
class City;
class Weapon;
/*游戏中对象的集体声明结束*/

/*全局常量的定义*/
const int MAXN = 1 << 16;
const int MaxQueueLen = 10050;
const int ProduceQueue[][5] = { { 4, 3, 0, 1, 2 }, { 1, 2, 3, 0, 4 } };
const char COLOR[][10] = { "red", "blue" };
const char TYPE[][10] = { "dragon", "ninja", "iceman", "lion", "wolf" };
/*全局常量的定义结束*/

/*全局变量的声明*/
int countCityNum, kase, M, N, R, K, T;
int dragonHp, ninjaHp, icemanHp, lionHp, wolfHp;
int dragonAD, ninjaAD, icemanAD, lionAD, wolfAD;
Warrior * Queue [MaxQueueLen];
City* MyCity = NULL;
int curQueueLen;
/*全局变量的声明结束*/

/*时钟类的设计*/
class TimeClicker {
public:
	void Reset() { hour = 0; minute = 0; }
	int GetMinute() { return minute; }
	void PrintTime() { printf("%03d:%02d ", hour, minute); }
	bool isGameOver() { return (hour * 60 + minute) > T; }
	void Click(int x) { minute += x; if (minute >= 60) { ++hour; minute %= 60; } }
	int hour, minute;
}MyClock;
/*时钟类的设计结束*/

/*城市(City)类及基地(Headquarter)类的实现*/
class City {
public:
	int element, cityNum, Flag, winnerFlag;
	Warrior * WarriorInCity[2];
	Warrior * winner, * loser;
	City() : element(0), cityNum(++countCityNum), Flag(-1), winnerFlag(-1), winner(NULL), loser(NULL) { WarriorInCity[0] = WarriorInCity[1] = NULL; }
	void ProduceElement() { element += 10; }
	bool isBattleField() { return WarriorInCity[0] != NULL && WarriorInCity[1] != NULL; }
	int AttackPlayer() {
		if (Flag >= 0) return Flag;
		return (cityNum % 2) ? 0 : 1;
	}
	int ElementGotten(Warrior * w);
	bool CheckFlag(Warrior * w);
};

class Headquarter {
public:
	int warriorNum, element, birthCity, enemyNum, moveDir, state, tempElement, color;
	Warrior * newWarrior;
	void Reset(int color_, int birthCity_, int moveDir_) {
		warriorNum = 0; element = M; birthCity = birthCity_; state = tempElement = enemyNum = 0; moveDir = moveDir_; newWarrior = NULL; color = color_;
	}
	bool isOccupied() { return enemyNum >= 2; }
	void GainElement() { element += tempElement; tempElement = 0; }
	void ReportElement() { MyClock.PrintTime(); printf("%d elements in %s headquarter\n", element, COLOR[color]); }
	void Fall() { MyClock.PrintTime(); printf("%s headquarter was taken\n", COLOR[color]); }
	void ProduceNewWarrior();
	void EncourageWarrior();
}red, blue;
/*城市(City)类及基地(Headquarter)类的实现结束*/
/*部分成员函数在类外函数实现部分具体实现*/

/*武器(Weapon)类的实现*/
class Weapon {
public:
	int AD, kind, remain;
	Weapon(int AD_, int kind_, int remain_ = 3):AD(AD_), kind(kind_), remain(remain_) {
		if (kind == 1) AD = MAXN;
		else if (kind == 2) AD = R;
	}
	void Used() {
		if (kind == 0) AD *= 0.8;
		else if (kind == 2) --remain;
	}
	bool isBroken() {
		if (kind == 0) return AD <= 0;
		if (kind == 1) return false;
		if (kind == 2) return remain <= 0;
	}
};
/*武器(Weapon)类的实现结束*/

/*武士(Warrior)类及其派生类的实现*/
class Warrior {
public:
	int Hp, AD, num, cityNum, type;
	Headquarter * belong;
	bool deadForArrow, hasArrived;
	Weapon * myWeapon[3];
	void PrintInfo() { printf("%s %s %d", COLOR[belong->color], TYPE[type], num); }
	Warrior(Headquarter * belong_, int num_, int Hp_, int AD_, int type_): belong(belong_), num(num_), Hp(Hp_), AD(AD_), type(type_), cityNum(belong_->birthCity), deadForArrow(false), hasArrived(false) {
		MyClock.PrintTime(); PrintInfo(); printf(" born\n");
		for (int i = 0; i < 3; ++i) myWeapon[i] = NULL;
	}
	~Warrior(){ for (int i = 0; i < 3; ++i) if (myWeapon[i]) delete myWeapon[i]; };
	virtual void Attack(Warrior& enemy) {
		MyClock.PrintTime(); PrintInfo(); printf(" attacked "); enemy.PrintInfo(); printf(" in city %d with %d elements and force %d\n", cityNum, Hp, AD);
		enemy.Hp -= AD;
		if (hasSword()) { enemy.Hp -= hasSword()->AD; hasSword()->Used(); }
		if (enemy.Hp > 0) enemy.FightBack(*this);
	}
	virtual void FightBack(Warrior& enemy) {
		MyClock.PrintTime(); PrintInfo(); printf(" fought back against "); enemy.PrintInfo(); printf(" in city %d\n", cityNum);
		enemy.Hp -= (AD / 2);
		if (hasSword()) { enemy.Hp -= hasSword()->AD; hasSword()->Used(); }
	}
	virtual Weapon* hasSword() { return NULL; }
	virtual Weapon* hasBomb() { return NULL; }
	virtual Weapon* hasArrow() { return NULL; }
	virtual int Character(int, bool isWin = false) { return 0; }
	virtual int Character(Warrior& w) { }
	virtual void CheckWeapon() { }
	virtual void Move() {
		if (cityNum != 0 && cityNum != N + 1) MyCity[cityNum].WarriorInCity[belong->color] = NULL;
		if ((!belong->color && cityNum != N + 1) || (belong->color && cityNum != 0)) cityNum += belong->moveDir;
	}
	void Arrive() {
		if (cityNum != 0 && cityNum != N + 1) {
			MyClock.PrintTime(); PrintInfo(); printf(" marched to city %d with %d elements and force %d\n", cityNum, Hp, AD);
			MyCity[cityNum].WarriorInCity[belong->color] = this;
		} else if (!belong->color && cityNum == N + 1) {
			MyClock.PrintTime(); PrintInfo(); printf(" reached blue headquarter with %d elements and force %d\n", Hp, AD);
			++blue.enemyNum; hasArrived = true;
			if (blue.isOccupied()) blue.Fall();
		} else if (belong->color && cityNum == 0) {
			MyClock.PrintTime(); PrintInfo(); printf(" reached red headquarter with %d elements and force %d\n", Hp, AD);
			++red.enemyNum; hasArrived = true;
			if (red.isOccupied()) red.Fall();
		}
	}
	void Die() { MyClock.PrintTime(); PrintInfo(); printf(" was killed in city %d\n", cityNum); }
	bool isDead () { return Hp <= 0; }
	void BornWithWeapon (int x, Warrior * thisWarrior, int weaponNum = 0) {
		if (x == 0 && 0.2 * AD <= 0) { thisWarrior->myWeapon[weaponNum] = NULL; return; }
		thisWarrior->myWeapon[weaponNum] = new Weapon(0.2 * AD, x);
	}
	void ReportWeapon() {
		MyClock.PrintTime(); PrintInfo(); printf(" has ");
		bool hasWeapon = false;
		Weapon * thisWeapon = NULL;
		if (thisWeapon = hasArrow()) { printf("arrow(%d)", thisWeapon->remain); hasWeapon = true; }
		if (thisWeapon = hasBomb()) { printf("%sbomb", hasWeapon ? "," : ""); hasWeapon = true; }
		if (thisWeapon = hasSword()) { printf("%ssword(%d)", hasWeapon ? "," : "", thisWeapon->AD); hasWeapon = true; }
		if (!hasWeapon) printf("no weapon"); 
		printf("\n");
	}
	void UseArrow(Warrior& enemy) {
		Weapon * myArrow = hasArrow();
		if (myArrow != NULL) {
			enemy.Hp -= R; myArrow->Used(); this->CheckWeapon();
			MyClock.PrintTime(); PrintInfo(); printf(" shot");
			if (enemy.isDead()) { enemy.deadForArrow = true; printf(" and killed "); enemy.PrintInfo(); }
			printf("\n");
		}
	}
	void UseBomb(City& thisCity) {
		Weapon * myBomb = hasBomb();
		if (myBomb != NULL) {
			bool willDie = false;
			Warrior * enemy = NULL;
			enemy = thisCity.WarriorInCity[1 ^ belong->color];
			if (enemy->isDead()) return;
			int myTempHp = Hp, enemyTempHp = enemy->Hp;
			if (thisCity.AttackPlayer() != belong->color) {
				myTempHp -= enemy->AD;
				if (enemy->hasSword()) myTempHp -= enemy->hasSword()->AD;
				if (myTempHp <= 0) willDie = true;
			} else {
				enemyTempHp -= AD;
				if (hasSword()) enemyTempHp -= hasSword()->AD;
				if (enemyTempHp > 0 && enemy->type != 1) {
					myTempHp -= (enemy->AD / 2);
					if (enemy->hasSword()) myTempHp -= enemy->hasSword()->AD;
					if (myTempHp <= 0) willDie = true;
				}
			}
			if (willDie) {
				Hp -= hasBomb()->AD; enemy->Hp -= hasBomb()->AD;
				MyClock.PrintTime(); PrintInfo(); printf(" used a bomb and killed "); enemy->PrintInfo(); printf("\n");
			}
		}
	}
};

class Dragon : public Warrior {
public:
	double morale;
	Dragon(Headquarter* belong_, int num_, int Hp_ = dragonHp, int AD_ = dragonAD, int type_ = 0): Warrior(belong_, num_, Hp_, AD_, type_) {
		morale = (double)belong_->element / (double)dragonHp; printf("Its morale is %.2lf\n", morale);
		BornWithWeapon(num_ % 3, this);
	}
	int Character(int x, bool isWin = false) {
		switch (x) {
			case 0: MoraleChange(isWin); break;
			case 1: Yell(); break;
		}
		return 0;
	}
	void MoraleChange(bool isWin) { morale += (isWin?0.2:-0.2); }
	void Yell() { if (morale > 0.8) { MyClock.PrintTime(); PrintInfo(); printf(" yelled in city %d\n", cityNum); } }
	void CheckWeapon() { if (myWeapon[0] && myWeapon[0]->isBroken()) { delete myWeapon[0]; myWeapon[0] = NULL; } }
	Weapon* hasSword() { return (myWeapon[0] && myWeapon[0]->kind == 0) ? myWeapon[0] : NULL; }
	Weapon* hasBomb() { return (myWeapon[0] && myWeapon[0]->kind == 1) ? myWeapon[0] : NULL; }
	Weapon* hasArrow() { return (myWeapon[0] && myWeapon[0]->kind == 2) ? myWeapon[0] : NULL; }
};

class Ninja : public Warrior{
public:
	Ninja(Headquarter* belong_, int num_, int Hp_ = ninjaHp, int AD_ = ninjaAD, int type_ = 1): Warrior(belong_, num_, Hp_, AD_, type_) {
		BornWithWeapon(num_ % 3, this, 0);
		BornWithWeapon((num_ + 1) % 3, this, 1);
	}
	void FightBack(Warrior& enemy) { }
	void CheckWeapon() {
		if (myWeapon[0] && myWeapon[0]->isBroken()) { delete myWeapon[0]; myWeapon[0] = NULL; }
		if (myWeapon[1] && myWeapon[1]->isBroken()) { delete myWeapon[1]; myWeapon[1] = NULL; }
	}
	Weapon* hasSword() {
		if (myWeapon[0] && myWeapon[0]->kind == 0) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 0) return myWeapon[1];
		return NULL;
	}
	Weapon* hasBomb() {
		if (myWeapon[0] && myWeapon[0]->kind == 1) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 1) return myWeapon[1];
		return NULL;
	}
	Weapon* hasArrow() {
		if (myWeapon[0] && myWeapon[0]->kind == 2) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 2) return myWeapon[1];
		return NULL;
	}
};

class Iceman :public Warrior {
public:
	int meltStep;
	Iceman(Headquarter* belong_, int num_, int Hp_ = icemanHp, int AD_ = icemanAD, int type_ = 2):Warrior(belong_, num_, Hp_, AD_, type_), meltStep(0) {
		BornWithWeapon(num_ % 3, this);
	}
	void melt() {
		++meltStep;
		if (meltStep >= 2) {
			Hp = (Hp - 9 > 0) ? Hp - 9 : 1;
			AD += 20; meltStep = 0;
		}
	}
	void Move() {
		if (cityNum != 0 && cityNum != N + 1) MyCity[cityNum].WarriorInCity[belong->color] = NULL;
		if ((!belong->color && cityNum != N + 1) || (belong->color && cityNum != 0)) cityNum += belong->moveDir;
		melt();
	}
	void CheckWeapon() { if (myWeapon[0] && myWeapon[0]->isBroken()) { delete myWeapon[0]; myWeapon[0] = NULL; } }
	Weapon* hasSword() { return (myWeapon[0] && myWeapon[0]->kind == 0) ? myWeapon[0] : NULL; }
	Weapon* hasBomb() { return (myWeapon[0] && myWeapon[0]->kind == 1) ? myWeapon[0] : NULL; }
	Weapon* hasArrow() { return (myWeapon[0] && myWeapon[0]->kind == 2) ? myWeapon[0] : NULL; }
};

class Lion : public Warrior {
public:
	int tempHp, loyalty;
	Lion(Headquarter* belong_, int num_, int Hp_ = lionHp, int AD_ = lionAD, int type_ = 3):Warrior(belong_, num_, Hp_, AD_, type_) {
		loyalty = belong_->element; printf("Its loyalty is %d\n", loyalty);
	}
	int Character(int x, bool isWin = false) {
		switch (x) {
			case 0: SetTempHp(); break;
			case 1: LoyaltyLower(); break;
			case 2: return CheckRunAway(); break;
			case 3: return GetTempHp(); break;
		} return 0;
	}
	int GetTempHp() { return tempHp; }
	void SetTempHp() { tempHp = Hp; }
	void LoyaltyLower() { if (loyalty > 0) loyalty -=  K; }
	int CheckRunAway() {
		if (loyalty <= 0 && cityNum != ((belong->color) ? 0 : N + 1)) {
			MyClock.PrintTime(); PrintInfo(); printf(" ran away\n"); return 1;
		} return 0;
	}
};

class Wolf :public Warrior {
public:
	Wolf(Headquarter* belong_, int num_, int Hp_ = wolfHp, int AD_ = wolfAD, int type_ = 4):Warrior(belong_, num_, Hp_, AD_, type_) { }
	int Character(Warrior& w) { GainWeapon(w); return 0; }
	void CheckWeapon() {
		if (myWeapon[0] && myWeapon[0]->isBroken()) { delete myWeapon[0]; myWeapon[0] = NULL; }
		if (myWeapon[1] && myWeapon[1]->isBroken()) { delete myWeapon[1]; myWeapon[1] = NULL; }
		if (myWeapon[2] && myWeapon[2]->isBroken()) { delete myWeapon[2]; myWeapon[2] = NULL; }
	}
	Weapon* hasSword() {
		if (myWeapon[0] && myWeapon[0]->kind == 0) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 0) return myWeapon[1];
		if (myWeapon[2] && myWeapon[2]->kind == 0) return myWeapon[2];
		return NULL;
	}
	Weapon* hasBomb() {
		if (myWeapon[0] && myWeapon[0]->kind == 1) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 1) return myWeapon[1];
		if (myWeapon[2] && myWeapon[2]->kind == 1) return myWeapon[2];
		return NULL;
	}
	Weapon* hasArrow() {
		if (myWeapon[0] && myWeapon[0]->kind == 2) return myWeapon[0];
		if (myWeapon[1] && myWeapon[1]->kind == 2) return myWeapon[1];
		if (myWeapon[2] && myWeapon[2]->kind == 2) return myWeapon[2];
		return NULL;
	}
	void GainWeapon(Warrior& w) {
		this->CheckWeapon();
		if (!this->hasSword() && w.hasSword())
			for (int i = 0; i < 3; ++i) if (myWeapon[i] == NULL) {
				myWeapon[i] = new Weapon(w.hasSword()->AD, 0); break;
			}
		if (!this->hasBomb() && w.hasBomb())
			for (int i = 0; i < 3; ++i) if (myWeapon[i] == NULL) {
				myWeapon[i] = new Weapon(MAXN, 1); break;
			}
		if (!this->hasArrow() && w.hasArrow())
			for (int i = 0; i < 3; ++i) if (myWeapon[i] == NULL) {
				myWeapon[i] = new Weapon(R, 2, w.hasArrow()->remain); break;
			}
	}
};
/*武士(Warrior)类及其派生类的实现结束*/

/*类外函数和其他函数*/
bool cmp (Warrior * a, Warrior * b) {
	if (a == NULL) return false;
	if (b == NULL) return true;
	if (a->cityNum != b->cityNum) return a->cityNum < b->cityNum;
	return !a->belong->color;
}

int City::ElementGotten(Warrior * w) {
	int res = element; element = 0;
	MyClock.PrintTime(); w->PrintInfo(); printf(" earned %d elements for his headquarter\n", res);
	return res;
}

void Headquarter::ProduceNewWarrior() {
		if (state == ProduceQueue[color][0] && element >= dragonHp) {
			element -= dragonHp; state = (state + 1) % 5;
			newWarrior = new Dragon(this, ++warriorNum);
		}
		else if (state == ProduceQueue[color][1] && element >= ninjaHp) {
			element -= ninjaHp; state = (state + 1) % 5;
			newWarrior = new Ninja(this, ++warriorNum);
		}
		else if (state == ProduceQueue[color][2] && element >= icemanHp) {
			element -= icemanHp; state = (state + 1) % 5;
			newWarrior = new Iceman(this, ++warriorNum);
		}
		else if (state == ProduceQueue[color][3] && element >= lionHp) {
			element -= lionHp; state = (state + 1) % 5;
			newWarrior = new Lion(this, ++warriorNum);
		}
		else if (state == ProduceQueue[color][4] && element >= wolfHp) {
			element -= wolfHp; state = (state + 1) % 5;
			newWarrior = new Wolf(this, ++warriorNum);
		}
}

void MySort() {
	sort(Queue, Queue + curQueueLen, cmp);
	for (int i = 0; i < curQueueLen; ++i) 
		if (Queue[i] == NULL) { curQueueLen = i; break; }
}

void Headquarter::EncourageWarrior() {
	if (!color) for (int i = N; i > 0 && element >= 8; --i) {
		if (MyCity[i].winner != NULL && MyCity[i].winner->belong == this) {
			MyCity[i].winner->Hp += 8; element -= 8;
		}
	} else for (int i = 1; i <= N && element >= 8; ++i) {
			if (MyCity[i].winner != NULL && MyCity[i].winner->belong == this) {
			MyCity[i].winner->Hp += 8; element -= 8;
		}
	}
}

bool City::CheckFlag(Warrior * w) {
	bool res = false;
	int winnerColor = w->belong->color;
	if ((winnerColor != Flag) && (winnerColor == winnerFlag)) { Flag = winnerColor; res = true; }
	else if (winnerColor != winnerFlag) winnerFlag = winnerColor;
	return res;
}
/*类外函数和其他函数结束*/

/*游戏函数GamePlay*/
void GamePlay() {
	memset(Queue, 0, sizeof(Queue));
	curQueueLen = 0;
	while (!MyClock.isGameOver()) {
		switch (MyClock.GetMinute()) {
			case 0:
				red.ProduceNewWarrior(); blue.ProduceNewWarrior();
				if (red.newWarrior) { Queue[curQueueLen++] = red.newWarrior; red.newWarrior = NULL; }
				if (blue.newWarrior) { Queue[curQueueLen++] = blue.newWarrior; blue.newWarrior = NULL; }
				MyClock.Click(5); break;
			case 5:
				MySort();
				for (int i = 0; i < curQueueLen; ++i)
					if (Queue[i] != NULL && !Queue[i]->hasArrived && Queue[i]->type == 3 && Queue[i]->Character(2)) {
							if (Queue[i]->cityNum != 0 && !Queue[i]->belong->color) MyCity[Queue[i]->cityNum].WarriorInCity[0] = NULL;
							else if (Queue[i]->cityNum != N + 1 && Queue[i]->belong->color) MyCity[Queue[i]->cityNum].WarriorInCity[1] = NULL;
							delete Queue[i]; Queue[i] = NULL;
					}
				MyClock.Click(5); break;
			case 10:
				MySort();
				for (int i = 0; i < curQueueLen; ++i)
					if (Queue[i] != NULL && !Queue[i]->hasArrived) Queue[i]->Move();
				MySort();
				for (int i = 0; i < curQueueLen; ++i)
					if (Queue[i] != NULL && !Queue[i]->hasArrived) Queue[i]->Arrive();
				MyClock.Click(10); break;
			case 20:
				for (int i = 1; i <= N; ++i) MyCity[i].ProduceElement();
				MyClock.Click(10); break;
			case 30:
				for (int i = 1; i <= N; ++i) {
					if (MyCity[i].isBattleField()) continue;
					if (MyCity[i].WarriorInCity[0] != NULL && MyCity[i].WarriorInCity[1] == NULL) red.element += MyCity[i].ElementGotten(MyCity[i].WarriorInCity[0]);
					else if (MyCity[i].WarriorInCity[1] != NULL && MyCity[i].WarriorInCity[0] == NULL) blue.element += MyCity[i].ElementGotten(MyCity[i].WarriorInCity[1]);
				} MyClock.Click(5); break;
			case 35:
				//Use Arrow
				for (int i = 0; i < curQueueLen; ++i) {
					if (!Queue[i]->hasArrow() || Queue[i]->hasArrived) continue;
					int nextCity = Queue[i]->cityNum + Queue[i]->belong->moveDir;
					if (nextCity == 0 || nextCity == N + 1) continue;
					if (MyCity[nextCity].WarriorInCity[1 ^ Queue[i]->belong->color])
						Queue[i]->UseArrow(*(MyCity[nextCity].WarriorInCity[1 ^ Queue[i]->belong->color]));
				}  MyClock.Click(3); break;
			case 38:
				//Use Bomb
				for (int i = 0; i < curQueueLen; ++i) {
					if (!Queue[i]->hasBomb() || Queue[i]->hasArrived) continue;
					if (Queue[i]->isDead()) continue;
					int thisCity = Queue[i]->cityNum;
					if (!MyCity[thisCity].isBattleField()) continue;
					Queue[i]->UseBomb(MyCity[thisCity]);
				} MyClock.Click(2); break;
			case 40:
				//Duel
				//首先处理被炸死的
				for (int i = 0; i < curQueueLen; ++i)
					if (Queue[i]->isDead() && !Queue[i]->deadForArrow) { 
						MyCity[Queue[i]->cityNum].WarriorInCity[Queue[i]->belong->color] = NULL;
						delete Queue[i]; Queue[i] = NULL;
					}
				MySort();
				for (int i = 1; i <= N; ++i) {
					MyCity[i].winner = NULL; MyCity[i].loser = NULL;
					bool bothDeadForArrow = false;
					if (!MyCity[i].isBattleField()) continue;
					//记录狮子的战前生命
					if (MyCity[i].WarriorInCity[0]->type == 3) MyCity[i].WarriorInCity[0]->Character(0);
					if (MyCity[i].WarriorInCity[1]->type == 3) MyCity[i].WarriorInCity[1]->Character(0);
					//处理有武士被射死的情况
					//最后一个else进入两位武士战斗阶段
					if (MyCity[i].WarriorInCity[0]->isDead() && MyCity[i].WarriorInCity[1]->isDead()) {
						bothDeadForArrow = true;
					} else if (MyCity[i].WarriorInCity[0]->isDead()) {
						MyCity[i].winner = MyCity[i].WarriorInCity[1];
						MyCity[i].loser = MyCity[i].WarriorInCity[0];
					} else if (MyCity[i].WarriorInCity[1]->isDead()) {
						MyCity[i].winner = MyCity[i].WarriorInCity[0];
						MyCity[i].loser = MyCity[i].WarriorInCity[1];
					} else {
						if (!MyCity[i].AttackPlayer()) {
								MyCity[i].WarriorInCity[0]->Attack(*(MyCity[i].WarriorInCity[1]));
								if (MyCity[i].WarriorInCity[0]->isDead()) MyCity[i].WarriorInCity[0]->Die();
								if (MyCity[i].WarriorInCity[1]->isDead()) MyCity[i].WarriorInCity[1]->Die();
								if (MyCity[i].WarriorInCity[0]->isDead() && !MyCity[i].WarriorInCity[1]->isDead()) { MyCity[i].winner = MyCity[i].WarriorInCity[1]; MyCity[i].loser = MyCity[i].WarriorInCity[0]; }
								else if (!MyCity[i].WarriorInCity[0]->isDead() && MyCity[i].WarriorInCity[1]->isDead()) { MyCity[i].winner = MyCity[i].WarriorInCity[0]; MyCity[i].loser = MyCity[i].WarriorInCity[1]; }
						} else {
								MyCity[i].WarriorInCity[1]->Attack(*(MyCity[i].WarriorInCity[0]));
								if (MyCity[i].WarriorInCity[0]->isDead()) MyCity[i].WarriorInCity[0]->Die();
								if (MyCity[i].WarriorInCity[1]->isDead()) MyCity[i].WarriorInCity[1]->Die();
								if (MyCity[i].WarriorInCity[0]->isDead() && !MyCity[i].WarriorInCity[1]->isDead()) { MyCity[i].winner = MyCity[i].WarriorInCity[1]; MyCity[i].loser = MyCity[i].WarriorInCity[0]; }
								else if (!MyCity[i].WarriorInCity[0]->isDead() && MyCity[i].WarriorInCity[1]->isDead()) { MyCity[i].winner = MyCity[i].WarriorInCity[0]; MyCity[i].loser = MyCity[i].WarriorInCity[1]; }
						}
					}
					//战斗结束,处理各种特性
					if (MyCity[i].WarriorInCity[0]->type == 0 && MyCity[i].WarriorInCity[0] != MyCity[i].winner) MyCity[i].WarriorInCity[0]->Character(0, false);
					if (MyCity[i].WarriorInCity[1]->type == 0 && MyCity[i].WarriorInCity[1] != MyCity[i].winner) MyCity[i].WarriorInCity[1]->Character(0, false);
					if (MyCity[i].WarriorInCity[0]->type == 0 && !MyCity[i].AttackPlayer() && !MyCity[i].WarriorInCity[0]->isDead()) MyCity[i].WarriorInCity[0]->Character(1);
					if (MyCity[i].WarriorInCity[1]->type == 0 && MyCity[i].AttackPlayer() && !MyCity[i].WarriorInCity[1]->isDead()) MyCity[i].WarriorInCity[1]->Character(1);
					if (MyCity[i].WarriorInCity[0]->type == 3 && MyCity[i].WarriorInCity[0] != MyCity[i].winner) MyCity[i].WarriorInCity[0]->Character(1);
					if (MyCity[i].WarriorInCity[1]->type == 3 && MyCity[i].WarriorInCity[1] != MyCity[i].winner) MyCity[i].WarriorInCity[1]->Character(1);
					//处理旗帜
					if (MyCity[i].winner == NULL && !bothDeadForArrow) MyCity[i].winnerFlag = -1;
					if (MyCity[i].winner) {
						if (MyCity[i].winner->type == 0) MyCity[i].winner->Character(0, true);
						else if (MyCity[i].winner->type == 4) MyCity[i].winner->Character(*MyCity[i].loser);
						if (MyCity[i].loser && MyCity[i].loser->type == 3 && MyCity[i].loser->Character(3) > 0) MyCity[i].winner->Hp += MyCity[i].loser->Character(3);
						bool isFlagChange = MyCity[i].CheckFlag(MyCity[i].winner);
						MyCity[i].winner->belong->tempElement += MyCity[i].ElementGotten(MyCity[i].winner);
						if (isFlagChange) { MyClock.PrintTime(); printf("%s flag raised in city %d\n", COLOR[MyCity[i].Flag], i); }
					}
				}
				//死者退场
				for (int i = 0; i < curQueueLen; ++i)
					if (Queue[i]->isDead()) { 
						MyCity[Queue[i]->cityNum].WarriorInCity[Queue[i]->belong->color] = NULL;
						delete Queue[i]; Queue[i] = NULL;
					}
				MySort();
				red.EncourageWarrior(); blue.EncourageWarrior();
				red.GainElement(); blue.GainElement();
				MyClock.Click(10); break;
			case 50:
				red.ReportElement(); blue.ReportElement();
				MyClock.Click(5); break;
			case 55:
				for (int i = 0; i < curQueueLen; ++i) 
					if (!Queue[i]->belong->color) {
						Queue[i]->CheckWeapon(); Queue[i]->ReportWeapon();
					}
				for (int i = 0; i < curQueueLen; ++i) 
					if (Queue[i]->belong->color) {
						Queue[i]->CheckWeapon(); Queue[i]->ReportWeapon();
					}
				MyClock.Click(5); break;
		}
		if (red.isOccupied() || blue.isOccupied()) break;
	}
}
/*游戏函数GamePlay结束*/

int main(){
	// freopen("d:\\Myoutput.txt", "w", stdout); 
	scanf("%d", &kase);
	for (int nCase = 1; nCase <= kase; ++nCase) {
		scanf("%d%d%d%d%d", &M, &N, &R, &K, &T);
		scanf("%d%d%d%d%d", &dragonHp, &ninjaHp, &icemanHp, &lionHp, &wolfHp);
		scanf("%d%d%d%d%d", &dragonAD, &ninjaAD, &icemanAD, &lionAD, &wolfAD);
		MyClock.Reset(); countCityNum = -1;
		if (MyCity) delete [] MyCity; MyCity = new City[N + 1];
		red.Reset(0, 0, 1); blue.Reset(1, N + 1, -1);
		printf("Case %d:\n", nCase);
		GamePlay();
	}
	return 0;
}