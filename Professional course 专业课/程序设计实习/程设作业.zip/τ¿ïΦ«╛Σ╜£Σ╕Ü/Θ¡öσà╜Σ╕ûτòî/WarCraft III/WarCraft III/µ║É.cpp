#include<cstdio>
#include<iostream>
#include<iomanip>
#include<cmath>
#include<cstring>
#include<string>

using namespace std;

int M, N, R, K, T;
bool EndWar;

class headquarter;

class weapon;
class  sword;
class   bomb;
class  arrow;

class warrior;
class  dragon;
class   ninja;
class  iceman;
class    lion;
class    wolf;

class city;



class timeclass
{
public:
	int mh, mm;

	timeclass(int h0, int m0 = 0)
	{
		mh = h0;
		mm = m0;
	}

	timeclass& operator ++ (int k)
	{
		mh++;
		return *this;
	}

	void setMinute(int x)
	{
		mm = x;
	}

	void reset()
	{
		mh = 0;
		mm = 0;
	}

	int totMin()
	{
		return (60 * mh + mm);
	}

	void print()
	{
		printf("%03d:%02d", mh, mm);
	}

}MyTime(0);


//***********************  weapons declaration
class weapon
{
public:
	warrior* pWarrior;
	int atk;
	int type;

	static string weaponNameList[3];

	friend class warrior;
	friend class city;
	friend class headquarter;

	inline weapon(warrior* p);
	inline virtual ~weapon();
	inline virtual void IfValid();
	inline virtual void LaunchSkill(warrior* = NULL);
	inline virtual void Report();
};
string weapon::weaponNameList[3] = { "sword","bomb","arrow" };

class sword : public weapon
{
public:
	static const int id = 0;
	static string name;

	sword(warrior* p);
	inline virtual void IfValid();
	inline virtual void LaunchSkill(warrior*);
	inline virtual void Report();
};
string sword::name = "sword";

class bomb : public weapon
{
public:
	static const int id = 1;
	static string name;
	static const int atk = 2147483647;

	bomb(warrior*);
	inline virtual void LaunchSkill(warrior* enemy);
	inline virtual void Report();
};
string bomb::name = "bomb";

class arrow : public weapon
{
public:
	static const int id = 2;
	static string name;
	static int atk;

	int durability;

	arrow(warrior*);
	void IfValid();
	inline virtual void LaunchSkill(warrior*);
	inline virtual void Report();
};
string arrow::name = "arrow";
int arrow::atk = 0;

//***********************  warriors declaration
class warrior
{
public:
	headquarter* pHead;
	int id, atk, hp, type;
	weapon* pWeapon[3];
	city* loc;

	static int HPList[5];
	static int intrinsicATK[5];
	static int minHP;
	static string warriorNameList[5];
	


	// friend class declaration
	friend class headquarter;
	friend class city;
	friend class weapon;
	friend sword::sword(warrior*);


	//
	inline int newCityID();
	inline warrior(headquarter* ph, const int& n, const int& t);
	inline ~warrior();
	inline void setWeapon(const int& n);
	inline virtual void March();
	inline virtual void Attack(warrior* enemy);
	inline virtual void FightBack(warrior* enemy);
	inline short MockFightBack(warrior * enemy);
	inline short MockAttack(warrior * enemy);
	inline virtual void Winned(warrior* p = NULL);
	inline virtual void Drew();
	inline virtual void GoDie(warrior* enemy = NULL);
	inline virtual bool IfValid();
	inline virtual void RunAway()
	{
	}

	inline virtual void RefreshMeat();
	inline void ReportWeapon();
};
string warrior::warriorNameList[5] = { "dragon","ninja","iceman","lion","wolf" };
int warrior::HPList[5] = { 0 };
int warrior::intrinsicATK[5] = { 0 };
int warrior::minHP = 2147483647;

class dragon : public warrior
{
private:
	double morale;

public:
	static string name;

	inline dragon(headquarter* ph, const int& n);
	inline virtual void Winned(warrior* p = NULL);
	inline virtual void Survived();
	inline virtual void Drew();
};
string dragon::name = "dragon";

class ninja : public warrior
{
public:
	static string name;

	inline ninja(headquarter* ph, const int& n);
	inline virtual void FightBack(warrior* enemy);
};
string ninja::name = "ninja";

class iceman : public warrior
{
public:
	static string name;

	inline iceman(headquarter* ph, const int& n);
	inline virtual void March();
};
string iceman::name = "iceman";

class lion : public warrior
{
private:
	int loyalty;
	int meat;
public:
	static string name;

	inline lion(headquarter* ph, const int& n);
	inline virtual void Drew();
	inline virtual void RefreshMeat();
	inline virtual void GoDie(warrior* enemy);
	inline virtual void RunAway();

	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;
	friend class city;
};
string lion::name = "lion";


class wolf : public warrior
{
public:
	static string name;

	inline wolf(headquarter* ph, const int& n);
	void Disarm(warrior * enemy);
	inline virtual void Winned(warrior * p);
};
string wolf::name = "wolf";

//***********************  cities declaration
class city
{
public:
	int ID;
	// 0 is NULL, 1 is Red, -1 is Blue!
	short Flag;
	int Element;
	short LastWinner, CurrWinner;
	warrior* pWarrior[3][2];

	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;

	friend class weapon;
	friend class arrow;
	friend class bomb;
	friend class sword;

	friend class headquarter;

	inline city(const int & i);
	inline virtual void March();

	inline void ElementsBeGotten(warrior * p, int &);

	inline void ElementsBeGotten();

	inline void LetsFight();

	inline void ChangeWinner(int WinColor);

	inline bool ChangeFlag();

	inline void BattleNCheck(int& redEleGot, int& blueEleGot);

	inline void LetsShot();

	inline void LetsUseBomb();
	
	inline int totBlueWarrior()
	{
		return (pWarrior[0][1] != NULL);
	}

	inline int totRedWarrior()
	{
		return (pWarrior[2][1] != NULL);
	}

	inline int totWarrior()
	{
		return ((pWarrior[0][1] != NULL) + (pWarrior[2][1] != NULL));
	}

	inline short FightOrder()
	{
		if (Flag != 0)
		{
			return Flag;
		}
		else
		{
			if (ID % 2 == 1)
			{
				return 1;
			}
			else
			{
				return -1;
			}
		}
	}
};
city* CityList[25];


//***********************  headquarters declaration
class headquarter : public city
{
public:
	int color;
	string strcolor;
	int totEle;

	int EnemyInside;
	warrior* pEnemy[3];

	int totWarrior;
	int warriorID;
	int numOfType[5];
	warrior* pWarrior[10000];


	short currOrderOfOutputSoldier;
	int* OutputOrder;

	short AwardList[25];

	int cityIDofAwardList[25];
	static int  redOrder[5];
	static int blueOrder[5];

	//  friend class declaration 
	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;

	friend class weapon;
	friend class arrow;
	friend class bomb;
	friend class sword;

	friend class city;
	//  declaration over!


	inline headquarter(const int& x, const int& m);
	inline bool OutputWarrior(bool testonly);
	inline virtual void March();
	inline void ReportAllWeapon(headquarter * EnemyHead);
	inline void Award();
};
int headquarter:: redOrder[5] = { 2,3,4,1,0 };
int headquarter::blueOrder[5] = { 3,0,1,2,4 };

//***********************
//***********************  class declaration over!
//***********************  functions follow!
//***********************


//***********************  weapons' functions
weapon::weapon(warrior* p) :
	pWarrior(p)
{

}

weapon :: ~weapon()
{
	pWarrior->pWeapon[type] = NULL;
}

inline void weapon::IfValid()
{

}

inline void weapon::LaunchSkill(warrior* enemy)
{

}

inline void weapon::Report()
{

}

sword::sword(warrior* p) :
	weapon(p)
{
	weapon::type = id;
	atk = p->atk / 5;
}


inline void sword::IfValid()
{
	if (weapon::atk <= 0)
	{
		delete this;
	}
}

inline void sword::LaunchSkill(warrior* enemy)
{
	enemy->hp -= weapon::atk;
	weapon::atk = weapon::atk * 4 / 5;
	this->IfValid();
}

inline void sword::Report()
{
	printf("sword(%d)", atk);
}

arrow::arrow(warrior* p) :
	weapon(p)
{
	weapon::type = id;
	durability = 3;
}


inline void arrow::LaunchSkill(warrior* PossibleEnemy = NULL)
{
	int newCityID = (pWarrior->loc)->ID + (pWarrior->pHead)->color;
	if (newCityID == 0 || newCityID == N + 1)
		return;
	PossibleEnemy = CityList[newCityID]->pWarrior[1 - (pWarrior->pHead)->color][1];
	
	if (PossibleEnemy)
	{
		PossibleEnemy->hp -= atk;
		--durability;

		MyTime.print();
		printf(" %s %s %d shot",
			pWarrior->pHead->strcolor.c_str(), 
			pWarrior->warriorNameList[pWarrior->type].c_str(),
			pWarrior->id);
		if (PossibleEnemy->IfValid())
		{
			printf("\n");
		}
		else
		{
			printf(" and killed %s %s %d\n",
				PossibleEnemy->pHead->strcolor.c_str(),
				PossibleEnemy->warriorNameList[PossibleEnemy->type].c_str(),
				PossibleEnemy->id);
		}

		IfValid();
	}
}

inline void arrow::Report()
{
	printf("arrow(%d)", durability);
}

inline void arrow::IfValid()
{
	if (durability < 1)
	{
		delete this;
	}
}

bomb::bomb(warrior* p) :
	weapon(p)
{
	weapon::type = id;
}

inline void bomb::LaunchSkill(warrior* enemy)
{
	if (pWarrior->pHead->color == pWarrior->loc->FightOrder())
	{
		if (pWarrior->MockAttack(enemy) == enemy->pHead->color)
		{
			pWarrior->hp -= atk;
			enemy->hp -= atk;
			
			MyTime.print();
			printf(" %s %s %d used a bomb and killed %s %s %d\n",
				pWarrior->pHead->strcolor.c_str(), pWarrior->warriorNameList[pWarrior->type].c_str(), pWarrior->id,
				enemy->pHead->strcolor.c_str(), enemy->warriorNameList[enemy->type].c_str(), enemy->id
				);

			pWarrior->GoDie();
			enemy->GoDie();
		}
	}
	else
	{
		if (enemy->MockAttack(pWarrior) == enemy->pHead->color)
		{
			pWarrior->hp -= atk;
			enemy->hp -= atk;

			MyTime.print();
			printf(" %s %s %d used a bomb and killed %s %s %d\n",
				pWarrior->pHead->strcolor.c_str(), pWarrior->warriorNameList[pWarrior->type].c_str(), pWarrior->id,
				enemy->pHead->strcolor.c_str(), enemy->warriorNameList[enemy->type].c_str(), enemy->id
				);

			pWarrior->GoDie();
			enemy->GoDie();
		}
	}
}

inline void bomb::Report()
{
	printf("bomb");
}

//***********************  warriors' functions
inline void setHPList()
{
	warrior::minHP = 2147483647;
	for (int i = 0; i < 5; ++i)
	{
		scanf("%d", &warrior::HPList[i]);
		if (warrior::HPList[i] < warrior::minHP)
		{
			warrior::minHP = warrior::HPList[i];
		}
	}
}

inline void setIntrinsicATK()
{

	for (short i = 0; i < 5; i++)
	{
		scanf("%d", &warrior::intrinsicATK[i]);
	}
}

inline warrior::warrior(headquarter* ph, const int& n, const int& t) :
	pHead(ph), id(n), type(t), atk(intrinsicATK[t])
{
	hp = HPList[type];
	memset(pWeapon, 0, sizeof(pWeapon));
	ph->totEle -= hp;
	++ph->numOfType[t];

	if (ph->color > 0)
	{
		loc = CityList[0];
	}
	else
	{
		loc = CityList[n + 1];
	}

		printf("%03d:%02d %s %s %d born\n",MyTime.mh, MyTime.mm,ph->strcolor.c_str(), warriorNameList[t].c_str(), id);
}

inline warrior :: ~warrior()
{
	if (loc->pWarrior[0][1] == this)
	{
		loc->pWarrior[0][1] = NULL;
	}
	if (loc->pWarrior[2][1] == this)
	{
		loc->pWarrior[2][1] = NULL;
	}
	for (int i = 0; i < 3; ++i)
	{
		if (pWeapon[i])
		{
			delete pWeapon[i];
		}
		pWeapon[i] = NULL;
	}


	int i;
	for (i = 1; pHead->pWarrior[i] != this; i++);
	for (; i < pHead->totWarrior; pHead->pWarrior[i] = pHead->pWarrior[i + 1], i++);

	--pHead->totWarrior;
	--pHead->numOfType[type];
}

inline void warrior::setWeapon(const int& n)
{
	switch (n % 3)
	{
	case 0: pWeapon[0] = new sword(this); pWeapon[0]->IfValid(); break;
	case 1: pWeapon[1] = new bomb (this);  break;
	case 2: pWeapon[2] = new arrow(this); break;
	}
}

inline void warrior::March()
{

}

inline int warrior::newCityID()
{
	return ((loc->ID) + (pHead->color));
}

inline void warrior::Winned(warrior* p)
{
	loc->LastWinner = loc->CurrWinner;
	loc->CurrWinner = pHead->color;

	pHead->AwardList[loc->ID] = 1;
}

inline void warrior::Drew()
{

}

inline void warrior::GoDie(warrior* p)
{
	delete this;
}

inline bool warrior::IfValid()
{
	return(hp > 0);
}

inline void warrior::Attack(warrior* enemy)
{
	MyTime.print();
	printf(" %s %s %d attacked %s %s %d in city %d with %d elements and force %d\n",
		pHead->strcolor.c_str(), warriorNameList[type].c_str(), id,
		enemy->pHead->strcolor.c_str(), enemy->warriorNameList[enemy->type].c_str(), enemy->id,
		loc->ID, hp, atk);


	enemy->hp -= atk;

	if (pWeapon[0])
	{
		pWeapon[0]->LaunchSkill(enemy);
	}

	if (enemy->IfValid())
	{
		enemy->FightBack(this);
	}

	if (hp <= 0)
	{
		MyTime.print();
		printf(" %s %s %d was killed in city %d\n",
			this->pHead->strcolor.c_str(), this->warriorNameList[this->type].c_str(),
			this->id, this->loc->ID);
	}
	if (enemy->hp <= 0)
	{
		MyTime.print();
		printf(" %s %s %d was killed in city %d\n",
			enemy->pHead->strcolor.c_str(), enemy->warriorNameList[enemy->type].c_str(),
			enemy->id, enemy->loc->ID);
	}
}

inline void warrior::FightBack(warrior* enemy)
{
	MyTime.print();
	printf(" %s %s %d fought back against %s %s %d in city %d\n",
		pHead->strcolor.c_str(), warriorNameList[type].c_str(), id,
		enemy->pHead->strcolor.c_str(), enemy->warriorNameList[enemy->type].c_str(), enemy->id,
		loc->ID);
	
		
	enemy->hp -= atk / 2;

	if (pWeapon[0])
	{
		pWeapon[0]->LaunchSkill(enemy);
	}

}

inline short warrior::MockFightBack(warrior* enemy)
{
	if (type == 1)   // is a ninja
	{
		return 0;
	}
	else
	{
		int MockAtk = atk / 2;
		if (pWeapon[0])
		{
			MockAtk += pWeapon[0]->atk;
		}

		if (MockAtk >= enemy->hp)
		{
			return pHead->color;
		}
		else
		{
			return 0;
		}
	}
	return 0;
}

inline short warrior::MockAttack(warrior* enemy)
{
	int MockAtk = atk;
	if (pWeapon[0])
	{
		MockAtk += pWeapon[0]->atk;
	}
	if (MockAtk >= enemy->hp)
	{
		return pHead->color;
	}
	else
	{
		return enemy->MockFightBack(this);
	}
}

inline void warrior::RefreshMeat()
{

}

inline void warrior::ReportWeapon()
{
	MyTime.print();
	printf(" %s %s %d has ", pHead->strcolor.c_str(), warriorNameList[type].c_str(), id);


	int num = (pWeapon[0] != NULL) + (pWeapon[1] != NULL) + (pWeapon[2] != NULL);	
	switch (num)
	{
	case 0:
		printf("no weapon\n");
		break;
	default:
		for (int i = 2; (i >= 0) && (num > 0); i--)
		{
			if (pWeapon[i])
			{
				pWeapon[i]->Report();
				if (num > 1)
				{
					printf(",");
				}
				else
				{
					printf("\n");
				}
				--num;
			}
		}
		break;
	}
}

//**************************************DRAGON
inline dragon::dragon(headquarter* ph, const int& n) :
	warrior(ph, n, 0)
{
	morale = ((double) ph->totEle) / hp;
	setWeapon(n);

	if (hp == 80 && pHead->totEle % 40 == 10)
	{
		printf("Its morale is %.2f\n", morale + 1e-5);
		return;
	}

	printf("Its morale is %.2f\n", morale);
}

inline void dragon::Winned(warrior* p)
{
	warrior::Winned();
	morale += 0.2;
	Survived();
}

inline void dragon::Drew()
{
	morale -= 0.2;
	Survived();
}

inline void dragon::Survived()
{
	if ((morale > 0.8) && (loc->FightOrder() == pHead->color))
	{
		printf("%03d:%02d %s %s %d yelled in city %d\n",
			MyTime.mh, MyTime.mm, pHead->strcolor.c_str(),
			name.c_str(), id, loc->ID);
	}

}

//**************************************NINJA
inline ninja::ninja(headquarter* ph, const int& n) :
	warrior(ph, n, 1)
{
	setWeapon(n);
	setWeapon(n + 1);

	//printf("It has a %s and a %s\n", pWeapon[n % 3]->weaponNameList[n % 3].c_str(), pWeapon[(n + 1) % 3]->weaponNameList[(n + 1) % 3].c_str());
}

inline void ninja::FightBack(warrior* enemy)
{

}

//**************************************ICEMAN
inline iceman::iceman(headquarter* ph, const int& n) :
	warrior(ph, n, 2)
{
	setWeapon(n);
}

inline void iceman::March()
{
	if (pHead->color > 0)
	{
		if (!(loc->ID & 1))
		{
			hp -= 9;
			atk += 20;
			if (hp <1)
				hp = 1;
		}
	}
	else if (pHead->color < 0)
	{
		if (!((N + 1 - loc->ID) & 1))
		{
			hp -= 9;
			atk += 20;
			if (hp <1)
				hp = 1;
		}
	}

}

//**************************************LION
inline lion::lion(headquarter* ph, const int& n) :
	warrior(ph, n, 3)
{
	loyalty = ph->totEle;
	printf("Its loyalty is %d\n", loyalty);
}

inline void lion::Drew()
{
	loyalty -= K;
}

inline void lion::RunAway()
{
	if (loyalty <= 0 && !((loc->ID == N + 1 && pHead->color > 0) || (loc->ID == 0 && pHead->color < 0)))
	{
		printf("%03d:%02d %s lion %d ran away\n",
			MyTime.mh, MyTime.mm, pHead->strcolor.c_str(), id);
		delete this;
	}
}

inline void lion::RefreshMeat()
{
	if (hp > 0)
	{
		meat = hp;
	}
	else
	{
		meat = 0;
	}
}

inline void lion::GoDie(warrior* enemy)
{
	if (enemy)
	{
		enemy->hp += meat;
	}
	warrior::GoDie();
}

//**************************************WOLF
inline wolf::wolf(headquarter* ph, const int& n) :
	warrior(ph, n, 4)
{

}

inline void wolf::Disarm(warrior* enemy)
{
	for (int i = 0; i < 3; i++)
	{
		if (pWeapon[i] == NULL && enemy->pWeapon[i] != NULL)
		{
			enemy->pWeapon[i]->pWarrior = this;
			pWeapon[i] = enemy->pWeapon[i];
			enemy->pWeapon[i] = NULL;
		}
	}
}

inline void wolf::Winned(warrior* p = NULL)
{
	if (p)
	{
		Disarm(p);
	}
	warrior::Winned();
}

//***********************  cities' functions
inline city::city(const int& i)
{
	memset(pWarrior, 0, sizeof(pWarrior));
	ID = i;
	LastWinner = 0;
	CurrWinner = 0;
	Element = 0;
	Flag = 0;
}

inline void city::March()
{
	const int& i = ID;

	pWarrior[2][0] = pWarrior[2][1];
	pWarrior[2][1] = NULL;
	if (CityList[i - 1]->pWarrior[2][0])
	{
		pWarrior[2][1] = CityList[i - 1]->pWarrior[2][0];
		CityList[i - 1]->pWarrior[2][0] = NULL;
		pWarrior[2][1]->loc = this;
		// Iceman will change
		pWarrior[2][1]->March();

		printf("%03d:%02d red %s %d marched to city %d with %d elements and force %d\n",
			MyTime.mh, MyTime.mm, (pWarrior[2][1]->warriorNameList[pWarrior[2][1]->type]).c_str(),
			pWarrior[2][1]->id, ID, pWarrior[2][1]->hp, pWarrior[2][1]->atk);
	}

	if (CityList[i + 1]->pWarrior[0][1])
	{
		pWarrior[0][1] = CityList[i + 1]->pWarrior[0][1];
		CityList[i + 1]->pWarrior[0][1] = NULL;
		pWarrior[0][1]->loc = this;
		// Iceman will change
		pWarrior[0][1]->March();

		printf("%03d:%02d blue %s %d marched to city %d with %d elements and force %d\n",
			MyTime.mh, MyTime.mm, (pWarrior[0][1]->warriorNameList[pWarrior[0][1]->type]).c_str(),
			pWarrior[0][1]->id, ID, pWarrior[0][1]->hp, pWarrior[0][1]->atk);
	}

}

inline void city::ElementsBeGotten(warrior* p, int& EleBuf)
{
	MyTime.print();
	printf(" %s %s %d earned %d elements for his headquarter\n",
		p->pHead->strcolor.c_str(),
		p->warriorNameList[p->type].c_str(),
		p->id, Element);

	EleBuf += Element;
	Element = 0;
}

inline void city::ElementsBeGotten()
{
	if (this->totWarrior() == 1)
	{
		if (pWarrior[0][1])
		{
			//ElementsBeGotten(pWarrior[0][1]);

			MyTime.print();
			printf(" blue %s %d earned %d elements for his headquarter\n",
				pWarrior[0][1]->warriorNameList[pWarrior[0][1]->type].c_str(),
				pWarrior[0][1]->id, Element);

			pWarrior[0][1]->pHead->totEle += Element;
			Element = 0;
		}
		else if (pWarrior[2][1])
		{
			//ElementsBeGotten(pWarrior[0][1]);
			
			MyTime.print();
			printf(" red %s %d earned %d elements for his headquarter\n",
				pWarrior[2][1]->warriorNameList[pWarrior[2][1]->type].c_str(),
				pWarrior[2][1]->id, Element);

			pWarrior[2][1]->pHead->totEle += Element;
			Element = 0;
			
		}
	}
}

inline void city::LetsFight()
{
	if (2 == totWarrior())
	{
		if ((pWarrior[0][1]->hp > 0) && (pWarrior[2][1]->hp > 0))
		{
			if (1 == FightOrder())
			{
				pWarrior[2][1]->Attack(pWarrior[0][1]);
			}
			else
			{
				pWarrior[0][1]->Attack(pWarrior[2][1]);
			}
		}
	}
}

inline void city::ChangeWinner(int WinColor)
{
	LastWinner = CurrWinner;
	CurrWinner = WinColor;
}

inline bool city::ChangeFlag()
{
	if (LastWinner == CurrWinner && CurrWinner != Flag && CurrWinner != 0)
	{
		Flag = CurrWinner;
		MyTime.print();
		printf(" %s flag raised in city %d\n", (Flag > 0 ? "red" : "blue"), ID);
		return true;
	}
	return false;
}

inline void city::BattleNCheck(int& redEleGot, int& blueEleGot)
{
	short Valid = (pWarrior[0][1]->hp > 0) + (pWarrior[2][1]->hp > 0);

	if (Valid == 0)
	{
		// All were shot to death!!! there is no battle!
		pWarrior[2][1]->GoDie();
		pWarrior[0][1]->GoDie();
		return;
	}

    if (Valid > 1)
	{
		pWarrior[0][1]->RefreshMeat();
		pWarrior[2][1]->RefreshMeat();
	}

	LetsFight();

	short survival = (pWarrior[0][1]->hp > 0) + (pWarrior[2][1]->hp > 0);
	if (1 == survival)
	{
		if (pWarrior[0][1]->hp > 0)
		{
			pWarrior[0][1]->Winned(pWarrior[2][1]);
			ElementsBeGotten(pWarrior[0][1], blueEleGot);

			if (Valid > 1)
			{
				pWarrior[2][1]->GoDie(pWarrior[0][1]);
			}
			else
			{
				pWarrior[2][1]->GoDie();
			}

			pWarrior[2][1] = NULL;
		}
		else
		{
			pWarrior[2][1]->Winned(pWarrior[0][1]);
			ElementsBeGotten(pWarrior[2][1], redEleGot);

			if (Valid > 1)
			{
				pWarrior[0][1]->GoDie(pWarrior[2][1]);
			}
			else
			{
				pWarrior[0][1]->GoDie();
			}


			pWarrior[0][1] = NULL;
		}
	}
	else   // ƽ��
	{
		LastWinner = CurrWinner;
		CurrWinner = 0;

		if (pWarrior[0][1])
		{
			if (pWarrior[0][1]->IfValid())
			{
				pWarrior[0][1]->Drew();
			}
			else
			{
				pWarrior[0][1]->GoDie();
			}
		}

		if (pWarrior[2][1])
		{
			if (pWarrior[2][1]->IfValid())
			{
				pWarrior[2][1]->Drew();
			}
			else
			{
				pWarrior[2][1]->GoDie();
			}
		}

	}

	ChangeFlag();
}

inline void city::LetsShot()
{

	if (pWarrior[2][1])
	{
		if (pWarrior[2][1]->pWeapon[2])
		{
			pWarrior[2][1]->pWeapon[2]->LaunchSkill();
		}
	}

	if (pWarrior[0][1])
	{
		if (pWarrior[0][1]->pWeapon[2])
		{
			pWarrior[0][1]->pWeapon[2]->LaunchSkill();
		}
	}
}

inline void city::LetsUseBomb()
{
	if (pWarrior[2][1] != NULL && pWarrior[0][1] != NULL)
	{
		if (pWarrior[2][1]->IfValid() && pWarrior[0][1]->IfValid())
		{
			if (pWarrior[2][1]->pWeapon[1])
			{
				pWarrior[2][1]->pWeapon[1]->LaunchSkill(pWarrior[0][1]);
			}
		}
	}

	if (pWarrior[2][1] != NULL && pWarrior[0][1] != NULL)
	{
		if (pWarrior[2][1]->IfValid() && pWarrior[0][1]->IfValid())
		{
			if (pWarrior[0][1]->pWeapon[1])
			{
				pWarrior[0][1]->pWeapon[1]->LaunchSkill(pWarrior[2][1]);
			}
		}
	}
}

//***********************  headquarters' functions
inline headquarter::headquarter(const int& x, const int& m) :
	city(x > 0 ? 0 : N + 1), color(x), totEle(m), totWarrior(0), warriorID(0), EnemyInside(0)
{
	memset(pWarrior, 0, sizeof(pWarrior));
	memset(numOfType, 0, sizeof(numOfType));
	memset(pEnemy, 0, sizeof(pEnemy));

	city::Flag = x;
	currOrderOfOutputSoldier = 0;

	if (color > 0)
	{
		strcolor = "red";
		OutputOrder = redOrder;
	}
	if (color < 0)
	{
		strcolor = "blue";
		OutputOrder = blueOrder;
	}
}

inline bool headquarter::OutputWarrior(bool testonly = false)
{

	// if succeed
	if (testonly)
		return true;

	currOrderOfOutputSoldier %= 5;
	const int& tmpid = OutputOrder[currOrderOfOutputSoldier];

	if (warrior::HPList[tmpid] > totEle)
		return false;

	++totWarrior;
	++warriorID;
	switch (tmpid)
	{
	case 0:pWarrior[totWarrior] = new dragon(this, warriorID); break;
	case 1:pWarrior[totWarrior] = new  ninja(this, warriorID); break;
	case 2:pWarrior[totWarrior] = new iceman(this, warriorID); break;
	case 3:pWarrior[totWarrior] = new   lion(this, warriorID); break;
	case 4:pWarrior[totWarrior] = new   wolf(this, warriorID); break;
	}

	city::pWarrior[1 + color][1] = pWarrior[totWarrior];
	pWarrior[totWarrior]->loc = this;
	++currOrderOfOutputSoldier;
	
	return true;

}

inline void headquarter::March()
{
	bool flag = false;

	if (color == 1)
	{
		city::pWarrior[2][0] = city::pWarrior[2][1];
		city::pWarrior[2][1] = NULL;
		if (city::pWarrior[0][1] = (CityList[1]->pWarrior[0][1]))
		{
			CityList[1]->pWarrior[0][1] = NULL;
			pEnemy[EnemyInside] = city::pWarrior[0][1];
			flag = true;
		}
	}
	if (color == -1)
	{
		if (city::pWarrior[2][1] = CityList[N]->pWarrior[2][0])
		{
			CityList[N]->pWarrior[2][0] = NULL;
			pEnemy[EnemyInside] = city::pWarrior[2][1];
			flag = true;
		}
	}

	if (flag)
	{
		pEnemy[EnemyInside]->loc = this;

		pEnemy[EnemyInside]->March();

		MyTime.print();
		printf(" %s %s %d reached %s headquarter with %d elements and force %d\n",
			pEnemy[EnemyInside]->pHead->strcolor.c_str(),
			(pEnemy[EnemyInside]->warriorNameList[pEnemy[EnemyInside]->type]).c_str(),
			pEnemy[EnemyInside]->id, this->strcolor.c_str(),
			pEnemy[EnemyInside]->hp, pEnemy[EnemyInside]->atk);

		++EnemyInside;
	}


	if (EnemyInside > 1)
	{
		EndWar = true;
		printf("%03d:%02d %s headquarter was taken\n", MyTime.mh, MyTime.mm, strcolor.c_str());
	}
}

inline void headquarter::ReportAllWeapon(headquarter* EnemyHead)
{
	if (color == -1)
	{
		if (EnemyHead->pEnemy[0])
		{
			EnemyHead->pEnemy[0]->ReportWeapon();
		}
	}

	for (int i = 1; i <= N; i++)
	{
		if (CityList[i]->pWarrior[1 + color][1])
		{
			CityList[i]->pWarrior[1 + color][1]->ReportWeapon();
		}
	}

	if (color == 1)
	{
		if (EnemyHead->pEnemy[0])
		{
			EnemyHead->pEnemy[0]->ReportWeapon();
		}
	}
}

inline void headquarter::Award()
{
	if (color == 1)
	{
		for (short i = 1; i <= N; ++i)
		{
			if (totEle > 7 && AwardList[i])
			{
				totEle -= 8;
				CityList[i]->pWarrior[2][1]->hp += 8;
			}
		}
	}
	else
	{
		for (short i = N; i > 0; --i)
		{
			if (totEle > 7 && AwardList[i])
			{
				totEle -= 8;
				CityList[i]->pWarrior[0][1]->hp += 8;
			}
		}
	}
}


//***********************  common functions

inline void DoAllMarch()
{
	for (int i = 0; i <= N + 1; i++)
	{
		CityList[i]->March();
	}
}





inline void work()
{
	//  ��ʼ��
	scanf("%d %d %d %d %d", &M, &N, &R, &K, &T);
	setHPList();
	setIntrinsicATK();
	arrow::atk = R;
	for (int i = 1; i <= N; i++)
	{
		CityList[i] = new city(i);
	}
	MyTime.reset();
	EndWar = false;

	headquarter  red( 1, M);
	headquarter blue(-1, M);
	CityList[0] = &red;
	CityList[N + 1] = &blue;

	//  ��ʼ��������

	while (!EndWar)
	{
		MyTime.setMinute(0);

		if (MyTime.totMin() > T)
			break;

		red.OutputWarrior();
		blue.OutputWarrior();

		/////////////////////////////////////////////////////////////////////////// ʨ������
		
		MyTime.setMinute(5);

		if (MyTime.totMin() > T)
			break;

		for (int i = 0; i <= N + 1; i++)              //  ʨ������
		{
			if (CityList[i]->pWarrior[2][1])
				CityList[i]->pWarrior[2][1]->RunAway();
			if (CityList[i]->pWarrior[0][1])
				CityList[i]->pWarrior[0][1]->RunAway();
		}

		/////////////////////////////////////////////////////////////////////////// March

		MyTime.setMinute(10);

		if (MyTime.totMin() > T)
			break;

		DoAllMarch();

		if (EndWar)
			break;

		///////////////////////////////////////////////////////////////////////////  ��������Element

		MyTime.setMinute(20);

		if (MyTime.totMin() > T)
			break;

		for (int i = 1; i <= N; i++)
		{
			CityList[i]->Element += 10;
		}

		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(30);

		if (MyTime.totMin() > T)
			break;

		for (int i = 1; i <= N; i++)
		{
			CityList[i]->ElementsBeGotten();
		}

		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(35);         
		
		if (MyTime.totMin() > T)
			break;

		//��Ҫ�ż��ˣ���!
		for (int i = 1; i <= N; i++)
		{
			CityList[i]->LetsShot();
		}
		
		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(38);          
		
		if (MyTime.totMin() > T)
			break;

		//��Ҫ��ը���ˣ�����
		for (int i = 1; i <= N; i++)
		{
			CityList[i]->LetsUseBomb();
		}


		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(40);         
		
		if (MyTime.totMin() > T)
			break;
		
		//�����ͻ������ʼ����ս����Ա��Ѹ�ٳ��룡����
		int redEleGot = 0;
		int blueEleGot = 0;
		memset(red.AwardList, 0, sizeof(red.AwardList));
		memset(blue.AwardList, 0, sizeof(blue.AwardList));
		for (int i = 1; i <= N; ++i)
		{
			if (CityList[i]->totWarrior() == 2)     
			{
				CityList[i]->BattleNCheck(redEleGot, blueEleGot);
			}
			else 
			{
				// ��һ��֮ǰ������������һ��û��
				if (CityList[i]->pWarrior[0][1])
				{
					if (!CityList[i]->pWarrior[0][1]->IfValid())
					{
						CityList[i]->pWarrior[0][1]->GoDie();

					}
				}
				else if (CityList[i]->pWarrior[2][1])
				{
					if (!CityList[i]->pWarrior[2][1]->IfValid())
					{
						CityList[i]->pWarrior[2][1]->GoDie();

					}
				}
			}
		}
		red.Award();
		blue.Award();
		red.totEle += redEleGot;
		blue.totEle += blueEleGot;
		
		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(50);

		if (MyTime.totMin() > T)
			break;

		MyTime.print();
		printf(" %d elements in red headquarter\n",  red.totEle);
		MyTime.print();
		printf(" %d elements in blue headquarter\n", blue.totEle);

		///////////////////////////////////////////////////////////////////////////

		MyTime.setMinute(55);

		if (MyTime.totMin() > T)
			break;

		red.ReportAllWeapon(&blue);
		blue.ReportAllWeapon(&red);

		///////////////////////////////////////////////////////////////////////////

		MyTime++; MyTime.setMinute(0);
		if (MyTime.totMin() > T)
			break;
	}
}

int main()
{

	freopen("Warcraft.in", "r", stdin);
	freopen("Warcraft.out", "w", stdout);

	int k;
	scanf("%d", &k);
	for (int i = 1; i <= k; i++)
	{
		printf("Case %d:\n", i);
		work();
	}


	return 0;
}
