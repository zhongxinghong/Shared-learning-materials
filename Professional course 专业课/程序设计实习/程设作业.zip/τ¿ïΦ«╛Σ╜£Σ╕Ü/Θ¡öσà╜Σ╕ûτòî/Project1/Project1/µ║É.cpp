#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>

using namespace std;

class headquarter;
class weapon;
class warrior;
class city;



class timeclass
{
public:
	int mh, mm;

	timeclass(int h0, int m0 = 0)
	{
		mh = h0;
		mm = m0;
	}

	timeclass& operator ++ (int k)
	{
		mh++;
		return *this;
	}

	void reset()
	{
		mh = 0;
		mm = 0;
	}
}MyTime(0);


//***********************  weapons declaration
class weapon
{
public:
	static string weaponNameList[3];
};
string weapon::weaponNameList[3] = { "sword","bomb","arrow" };

class sword : public weapon
{
public:
	static const int id = 0;
	static string name;
};
string sword::name = "sword";
//strcpy(sword :: name,"sword");

class bomb : public weapon
{
public:
	static const int id = 1;
	static string name;
};
string bomb::name = "bomb";
//strcpy(bomb :: name,"bomb");

class arrow : public weapon
{
public:
	static const int id = 2;
	static string name;
};
string arrow::name = "arrow";
//strcpy(arrow :: name,"arrow");


//***********************  warriors declaration
class warrior
{
protected:
	headquarter* pHead;
	int id, hp, atk, type;
	city* loc;
	weapon* pWeapon[3];

public:
	static int HPList[5];
	static int minHP;
	static string warriorNameList[5];

	// friend class declaration
	friend class headquarter;
	friend class city;
	friend class weapon;
	//

	inline static void setHPList();
	inline warrior(headquarter* ph, const int& n, const int& t);
	inline ~warrior();
	inline void setWeapon(const int& n);

};
string warrior :: warriorNameList[5] = { "dragon","ninja","iceman","lion","wolf" };
int warrior :: HPList[5] = { 0 };
int warrior::minHP = 2147483647;

class dragon : public warrior
{
private:
	double morale;


public:
	inline dragon(headquarter* ph, const int& n);
};

class ninja : public warrior
{
public:
	inline ninja(headquarter* ph, const int& n);
};

class iceman : public warrior
{
public:
	inline iceman(headquarter* ph, const int& n);
};

class lion : public warrior
{
private:
	int loyalty;

public:
	inline lion(headquarter* ph, const int& n);
};

class wolf : public warrior
{
public:
	inline wolf(headquarter* ph, const int& n);
};

//***********************  cities declaration
class city
{

};

//***********************  headquarters declaration
class headquarter
{
private:
	int color;
	string strcolor;
	int totEle;
	int EnemyInside;
	int totWarrior;
	int numOfType[5];
	warrior* pWarrior[10000];


	short currOrderOfOutputSoldier;
	int* OutputOrder;

public:
	bool IfStopMaking;
	static int  redOrder[5];
	static int blueOrder[5];

	//  friend class declaration 
	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;
	friend class city;
	//  declaration over!


	inline headquarter(const int& x, const int& m);
	inline bool OutputWarrior(bool testonly);
};
int headquarter::redOrder[5] = { 2,3,4,1,0 };
int headquarter::blueOrder[5] = { 3,0,1,2,4 };

//***********************
//***********************  class declaration over!
//***********************  functions follow!
//***********************


//***********************  warriors' functions
inline void setHPList()
{
	warrior :: minHP = 2147483647;
	for (int i = 0; i < 5; ++i)
	{
		scanf("%d", &warrior :: HPList[i]);
		if (warrior :: HPList[i] < warrior :: minHP)
		{
			warrior :: minHP = warrior :: HPList[i];
		}
	}
}

inline warrior::warrior(headquarter* ph, const int& n, const int& t) :
	pHead(ph), id(n), type(t)
{
	hp = HPList[type];
	memset(pWeapon, 0, sizeof(pWeapon));
	ph->totEle -= hp;
	++ph->numOfType[t];

	printf("%03d %s %s %d born with strength %d,%d %s in %s headquarter\n",
		MyTime.mh, ph->strcolor.c_str(), warriorNameList[t].c_str(), ph->totWarrior,
		HPList[t], ph->numOfType[t],
		warriorNameList[t].c_str(), ph->strcolor.c_str());
}

inline warrior :: ~warrior()
{
	--pHead->totWarrior;
	--pHead->numOfType[type];
}

inline void warrior::setWeapon(const int& n)
{
	switch (n % 3)
	{
	case 0: pWeapon[0] = new sword; break;
	case 1: pWeapon[1] = new bomb;  break;
	case 2: pWeapon[2] = new arrow; break;
	}
}

inline dragon::dragon(headquarter* ph, const int& n) :
	warrior(ph, n, 0)
{
	morale = ph->totEle / (double)hp;
	setWeapon(n);

	printf("It has a %s,and it's morale is %.2f\n",
		pWeapon[n % 3]->weaponNameList[n % 3].c_str(), morale);
}

inline ninja::ninja(headquarter* ph, const int& n) :
	warrior(ph, n, 1)
{
	setWeapon(n);
	setWeapon(n + 1);

	printf("It has a %s and a %s\n", pWeapon[n % 3]->weaponNameList[n % 3].c_str(), pWeapon[(n + 1) % 3]->weaponNameList[(n + 1) % 3].c_str());
}

inline iceman::iceman(headquarter* ph, const int& n) :
	warrior(ph, n, 2)
{
	setWeapon(n);

	printf("It has a %s\n", pWeapon[n % 3]->weaponNameList[n % 3].c_str());
}

inline lion::lion(headquarter* ph, const int& n) :
	warrior(ph, n, 3)
{
	loyalty = ph->totEle;
	printf("It's loyalty is %d\n", loyalty);
}

inline wolf::wolf(headquarter* ph, const int& n) :
	warrior(ph, n, 4)
{

}

//***********************  headquarters' functions
inline headquarter::headquarter(const int& x, const int& m) :
	color(x), totEle(m), totWarrior(0), EnemyInside(0), IfStopMaking(false)
{
	memset(pWarrior, 0, sizeof(pWarrior));
	memset(numOfType, 0, sizeof(numOfType));
	currOrderOfOutputSoldier = -1;

	if (color > 0)
	{
		strcolor = "red";
		OutputOrder = redOrder;
	}
	if (color < 0)
	{
		strcolor = "blue";
		OutputOrder = blueOrder;
	}
}

inline bool headquarter::OutputWarrior(bool testonly = false)
{
	if (IfStopMaking)
		return false;
	//  judge if the headquarter can output one
	//  if failed
	if (totEle < warrior::minHP)
	{
		IfStopMaking = true;
		printf("%03d %s headquarter stops making warriors\n", MyTime.mh, strcolor.c_str());
		return false;
	}

	// if succeed
	if (testonly)
		return true;

	++currOrderOfOutputSoldier;
	currOrderOfOutputSoldier %= 5;
	while (totEle < warrior::HPList[OutputOrder[currOrderOfOutputSoldier % 5]])
	{
		++currOrderOfOutputSoldier;
		currOrderOfOutputSoldier %= 5;
	}
	currOrderOfOutputSoldier %= 5;

	const int& tmpid = OutputOrder[currOrderOfOutputSoldier];
	++totWarrior;
	switch (tmpid)
	{
	case 0:pWarrior[totWarrior] = new dragon(this, totWarrior); break;
	case 1:pWarrior[totWarrior] = new  ninja(this, totWarrior); break;
	case 2:pWarrior[totWarrior] = new iceman(this, totWarrior); break;
	case 3:pWarrior[totWarrior] = new   lion(this, totWarrior); break;
	case 4:pWarrior[totWarrior] = new   wolf(this, totWarrior); break;
	}

	return true;

}


//***********************  common functions
inline void work()
{
	int m;
	scanf("%d", &m);
	setHPList();
	MyTime.reset();
	headquarter  red(1, m);
	headquarter blue(-1, m);

	bool flag1 =  red.OutputWarrior();
	bool flag2 = blue.OutputWarrior();
	while (flag1 || flag2)
	{
		MyTime++;
		flag1 =  red.OutputWarrior();
		flag2 = blue.OutputWarrior();
	}
}

int main()
{
	int k;
	scanf("%d", &k);
	for (int i = 1; i <= k; i++)
	{
		printf("Case:%d\n", i);
		work();
	}

	return 0;
}
