#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>

using namespace std;

class headquarter;
class weapon;
class warrior;
class city;



class timeclass
{
public:
	int mh, mm;

	timeclass(int h0, int m0 = 0)
	{
		mh = h0;
		mm = m0;
	}

	timeclass& operator ++ (int k)
	{
		mh++;
		return *this;
	}
	
	void setMinute(int& x)
	{
		mm = x;
	}
	
	void reset()
	{
		mh = 0;
		mm = 0;
	}
}MyTime(0);


//***********************  weapons declaration
class weapon
{
private:
	warrior* pWarrior;
	int atk;
	int type;
public:
	static string weaponNameList[3];
	
	friend class warrior;
	friend class city;
	friend class headquarter;	
	
	inline weapon(warrior* p);
	inline virtual ~weapon();
    inline virtual void IfValid();
	inline virtual void Attack(warrior* enemy);
	inline virtual void FightBack(warrior* enemy);
	inline virtual void Hurt(const int& nPower);
};
string weapon::weaponNameList[3] = { "sword","bomb","arrow" };

class sword : public weapon
{
public:
	static const int id = 0;
	static string name;
	static int atk;
	
	sword(warrior* p);
	void IfValid();
};
string sword::name = "sword";

class bomb : public weapon
{
public:
	static const int id = 1;
	static string name;
	static const int atk = 2147483647;
	
	bomb(warrior*);
};
string bomb::name = "bomb";

class arrow : public weapon
{
public:
	static const int id = 2;
	static string name;
	int durability;
	
	arrow(warrior*);
	void IfValid();
};
string arrow::name = "arrow";


//***********************  warriors declaration
class warrior
{
protected:
	headquarter* pHead;
	int id, hp, atk, type;
	city* loc;
	weapon* pWeapon[3];
	city* pCity;

public:
	static int HPList[5];
	static int minHP;
	static string warriorNameList[5];

	// friend class declaration
	friend class headquarter;
	friend class city;
	friend class weapon;
	friend sword :: sword(warrior*);

	//

	inline static void setHPList();
	inline warrior(headquarter* ph, const int& n, const int& t);
	inline ~warrior();
	inline void setWeapon(const int& n);
	inline virtual void March();


};
string warrior :: warriorNameList[5] = { "dragon","ninja","iceman","lion","wolf" };
int warrior :: HPList[5] = { 0 };
int warrior::minHP = 2147483647;

class dragon : public warrior
{
private:
	double morale;


public:
	inline dragon(headquarter* ph, const int& n);
};

class ninja : public warrior
{
public:
	inline ninja(headquarter* ph, const int& n);
};

class iceman : public warrior
{
public:
	inline iceman(headquarter* ph, const int& n);
	int StepCount;
};

class lion : public warrior
{
private:
	int loyalty;
	int meat;
public:
	inline lion(headquarter* ph, const int& n);
	
	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;
	friend class city;
};

class wolf : public warrior
{
public:
	inline wolf(headquarter* ph, const int& n);
};

//***********************  cities declaration
class city
{
	int ID;
	// 0 is NULL, 1 is Red, -1 is Blue!
	short Flag;
	int Element;
	short LastWinner;
	short totWarrior[3];
	warrior*  pWarrior[3][2];
};

//***********************  headquarters declaration
class headquarter : public city
{
private:
	int color;
	string strcolor;
	int totEle;
	
	int EnemyInside;
	warrior* pEnemy[3];
	
	int totWarrior;
	int numOfType[5];
	warrior* pWarrior[10000];


	short currOrderOfOutputSoldier;
	int* OutputOrder;

public:
	bool IfStopMaking;
	static int  redOrder[5];
	static int blueOrder[5];

	//  friend class declaration 
	friend class warrior;
	friend class dragon;
	friend class ninja;
	friend class iceman;
	friend class lion;
	friend class wolf;
	friend class city;
	//  declaration over!


	inline headquarter(const int& x, const int& m);
	inline bool OutputWarrior(bool testonly);
};
int headquarter::redOrder[5] = { 2,3,4,1,0 };
int headquarter::blueOrder[5] = { 3,0,1,2,4 };

//***********************
//***********************  class declaration over!
//***********************  functions follow!
//***********************


//***********************  weapons' functions
weapon :: weapon(warrior* p):
pWarrior(p)
{
	
}

weapon :: ~weapon()
{
	pWarrior->pWeapon[type] = NULL;
	delete this;
	
}

inline virtual void weapon :: IfValid()
{
	
}

inline virtual void weapon :: LaunchSkill(warrior* enemy)
{
	
}

sword :: sword(warrior* p):
weapon(p)
{
	atk = p->atk / 5;
}

inline virtual void sword :: IfValid()
{
	if (atk <= 0)
	{
		~sword();
	}
}

inline virtual void sword :: LaunchSkill(warrior* enemy)
{
	enemy->hp -= atk;
	atk = atk * 4 / 5;
	IfValid();
}

arrow :: arrow(warrior* p):
weapon(p)
{
	durability = 3; 
}

inline virtual void arrow :: LaunchSkill()
{
	int newCityID = pWarrior->loc->ID + pWarrior->pHead->color;
	warrior* PossibleEnemy = CityList[newCityID]->pWarrior[1 - pWarrior->pHead->color][1]
	if (PossibleEnemy)
	{
		PossibleEnemy->hp -= atk;
	}
}

inline virtual bool arrow :: IfValid()
{
	if (durability < 1)
	{
		~arrow();
	}
}

bomb :: bomb(warrior* p):
weapon(p)
{
}

inline virtual void bomb :: LaunchSkill(warrior* enemy)
{
	if 
}

//***********************  warriors' functions
inline void setHPList()
{
	warrior :: minHP = 2147483647;
	for (int i = 0; i < 5; ++i)
	{
		scanf("%d", &warrior :: HPList[i]);
		if (warrior :: HPList[i] < warrior :: minHP)
		{
			warrior :: minHP = warrior :: HPList[i];
		}
	}
}

inline warrior::warrior(headquarter* ph, const int& n, const int& t) :
	pHead(ph), id(n), type(t)
{
	hp = HPList[type];
	memset(pWeapon, 0, sizeof(pWeapon));
	ph->totEle -= hp;
	++ph->numOfType[t];
	
	pCity

	printf("%03d %s %s %d born with strength %d,%d %s in %s headquarter\n",
		MyTime.mh, ph->strcolor.c_str(), warriorNameList[t].c_str(), ph->totWarrior,
		HPList[t], ph->numOfType[t],
		warriorNameList[t].c_str(), ph->strcolor.c_str());
}

inline warrior :: ~warrior()
{
	int i;
	for (i = 1; pWarrior[i] != this; i++)
	for (; i < pHead->totWarrior; pWarrior[i] = pWarrior[i + 1], i++);

	--pHead->totWarrior;
	--pHead->numOfType[type];	
}

inline void warrior :: setWeapon(const int& n)
{
	switch (n % 3)
	{
	case 0: pWeapon[0] = new sword; break;
	case 1: pWeapon[1] = new bomb;  break;
	case 2: pWeapon[2] = new arrow; break;
	}
}

inline virtual void warrior :: March()
{
	int newCityID = loc->ID + pHead->color
	++CityList[newCityID]->totWarrior[pHead->color + 1];
	CityList[newCityID]->pWarrior[pHead->color + 1] = this;
	
	loc->pWarrior[pHead->color + 1] = NULL;
	--loc->totWarrior[pHead->color + 1];
	
	loc = CityList[newCityID];
}

inline virtual void warrior :: Winned(warrior* p = NULL)
{
	loc->LastWinner = pHead->color;
}

inline virtual void warrior :: Drew()
{
	
}

inline virtual void warrior :: GoDie()
{
	~warrior();
}

inline virtual bool warrior :: IfValid()
{
	
}

inline virtual void warrior :: Attack(warrior* enemy)
{
	enemy->hp -= atk;
	
	if (pWeapon[0])
	{
		pWeapon[0]->LaunchSkill(enemy);
	}
	
	if(enemy->IfValid())
	{
		enemy->FightBack(this);
	}
	else
	{
		Winned();
	}
}

inline virtual void warrior :: FightBack(warrior* enemy)
{
	enemy->hp -= atk / 2;
	
	if (pWeapon[0])
	{
		pWeapon[0]->LaunchSkill(enemy);
	}
	
	if(enemy->IfValid())
	{
		Drew();
		enemy->Drew();
	}
	else
	{
		Winned();
	}
}

inline virtual void warrior :: Survived()
{
	
}

inline virtual void warrior :: RefreshMeat()
{
	
} 

inline dragon :: dragon(headquarter* ph, const int& n) :
warrior(ph, n, 0)
{
	morale = ph->totEle / (double)hp;
	setWeapon(n);

	printf("It has a %s,and it's morale is %.2f\n",
		pWeapon[n % 3]->weaponNameList[n % 3].c_str(), morale);
}

inline virtual void dragon :: Winned(warrior* p = NULL)
{
	morale += 0.2;
}

inline virtual void dragon :: Drew()
{
	morale -= 0.2;
}

inline virtual void dragon :: Survived()
{
	if (morale > 0.8)
	{
		printf("%03d:%02d %s %s %d yelled in city %d\n",
		MyTime.mh, MyTime.mm, pHead->strcolor.c_str(),
		name.c_str(), id, loc->ID);
	}

}

inline ninja :: ninja(headquarter* ph, const int& n) :
warrior(ph, n, 1)
{
	setWeapon(n);
	setWeapon(n + 1);

	printf("It has a %s and a %s\n", pWeapon[n % 3]->weaponNameList[n % 3].c_str(), pWeapon[(n + 1) % 3]->weaponNameList[(n + 1) % 3].c_str());
}

inline virtual void ninja :: FightBack(warrior* enemy)
{
	
}

inline iceman :: iceman(headquarter* ph, const int& n) :
warrior(ph, n, 2)
{
	StepCount = 0;
	setWeapon(n);

	printf("It has a %s\n", pWeapon[n % 3]->weaponNameList[n % 3].c_str());
}

inline virtual void iceman :: March()
{
	warrior :: March();
	++StepCount;
	if (!(StepCount & 1))
	{
		hp -= 9;
		atk += 20;
		if (hp <1)
			hp = 1;
	}
}

inline lion :: lion(headquarter* ph, const int& n) :
warrior(ph, n, 3)
{
	loyalty = ph->totEle;
	printf("It's loyalty is %d\n", loyalty);
}

inline virtual void lion :: Drew()
{
	loyalty -= K;
	if (K <= 0 && ((loc->ID == n + 1 && pHead->color > 0) || (loc->ID == 0 && pHead->color < 0)) )
	{
		printf("%03d:%02d %s lion %d rand away\n",
		MyTime.mh, MyTime.mm, pHead->strcolor.c_str(), id);
	}
}

inline virtual void lion :; RefreshMeat()
{
	meat = hp;
}

inline virtual void lion :: GoDie(warrior* enemy)
{
	enemy->hp += meat;
	warrior :: GoDie();
}

inline wolf :: wolf(headquarter* ph, const int& n) :
warrior(ph, n, 4)
{

}

inline void wolf :: Disarm(warrior* enemy)
{
	for (int i = 0; i < 3; i++)
	{
		if (pWeapon[i] == NULL)
		{
			pWeapon[i] = enemy->pWeapon[i];
			enemy->pWeapon[i] = NULL;
		}
	}
} 

inline virtual void wolf :: Winned(warrior* p = NULL)
{
	if (p)
	{
		Disarm(p);
	}
}

//***********************  cities' functions
inline city :: city(const int& i)
{
	memset(this, 0, sizeof(city));
	ID = i;
}

//***********************  headquarters' functions
inline headquarter::headquarter(const int& x, const int& m) :
	color(x), totEle(m), totWarrior(0), EnemyInside(0), IfStopMaking(false)
{
	memset(pWarrior, 0, sizeof(pWarrior));
	memset(numOfType, 0, sizeof(numOfType));
	currOrderOfOutputSoldier = -1;

	if (color > 0)
	{
		strcolor = "red";
		OutputOrder = redOrder;
	}
	if (color < 0)
	{
		strcolor = "blue";
		OutputOrder = blueOrder;
	}
}

inline bool headquarter::OutputWarrior(bool testonly = false)
{
	if (IfStopMaking)
		return false;
	//  judge if the headquarter can output one
	//  if failed
	if (totEle < warrior::minHP)
	{
		IfStopMaking = true;
		printf("%03d %s headquarter stops making warriors\n", MyTime.mh, strcolor.c_str());
		return false;
	}

	// if succeed
	if (testonly)
		return true;

	++currOrderOfOutputSoldier;
	currOrderOfOutputSoldier %= 5;
	while (totEle < warrior::HPList[OutputOrder[currOrderOfOutputSoldier % 5]])
	{
		++currOrderOfOutputSoldier;
		currOrderOfOutputSoldier %= 5;
	}
	currOrderOfOutputSoldier %= 5;

	const int& tmpid = OutputOrder[currOrderOfOutputSoldier];
	++totWarrior;
	switch (tmpid)
	{
	case 0:pWarrior[totWarrior] = new dragon(this, totWarrior); break;
	case 1:pWarrior[totWarrior] = new  ninja(this, totWarrior); break;
	case 2:pWarrior[totWarrior] = new iceman(this, totWarrior); break;
	case 3:pWarrior[totWarrior] = new   lion(this, totWarrior); break;
	case 4:pWarrior[totWarrior] = new   wolf(this, totWarrior); break;
	}

	return true;

}


//***********************  common functions
inline void work()
{
	int m;
	scanf("%d", &m);
	setHPList();
	MyTime.reset();
	headquarter  red(1, m);
	headquarter blue(-1, m);

	bool flag1 =  red.OutputWarrior();
	bool flag2 = blue.OutputWarrior();
	while (flag1 || flag2)
	{
		MyTime++;
		flag1 =  red.OutputWarrior();
		flag2 = blue.OutputWarrior();
	}
}

int main()
{
	int k;
	scanf("%d", &k);
	for (int i = 1; i <= k; i++)
	{
		printf("Case:%d\n", i);
		work();
	}

	return 0;
}

