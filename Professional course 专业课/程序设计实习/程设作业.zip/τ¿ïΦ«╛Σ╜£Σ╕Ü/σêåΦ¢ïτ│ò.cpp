#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>

#define min(a, b) ( a< b ? a : b)
#define max(a, b) (a > b ? a : b)

using namespace std;

int minMax[22][22][500];
int w, h, m;

int DFS(short w, short h, int m)
{
	if (m + 1> w * h)
		return INT_MAX;

	if (m == 0)
		return (w * h);

	if (minMax[w][h][m] >= 0)
	{
		return minMax[w][h][m];
	}

	int ans = INT_MAX;
	int m1, m2;

	for (int i = 1; i < w; ++i)
	{
		for (int cut = 0; cut < m; ++cut)
		{
			m1 = DFS(i, h, cut);
			m2 = DFS(w - i, h, m - 1 - cut);
			ans = min(ans, max(m1, m2));
		}
	}

	for (int i = 1; i < h; ++i)
	{
		for (int cut = 0; cut < m; ++cut)
		{
			m1 = DFS(w, i, cut);
			m2 = DFS(w, h - i, m - 1 - cut);
			ans = min(ans, max(m1, m2));
		}
	}

	minMax[w][h][m] = ans;
	return ans;
}

inline void work()
{
	memset(minMax, -1, sizeof(minMax));
	int res = DFS(w, h, m - 1);
	printf("%d\n", res);
};

int main()
{
	scanf("%d %d %d", &w, &h, &m);
	while (!(w == 0 && h == 0 && m ==0))
	{
		work();
		scanf("%d %d %d", &w, &h, &m);
	}

	return 0;
}