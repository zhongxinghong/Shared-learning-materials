#include <iostream>

using namespace std;

int n;
int v[50];

int main()
{
	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		cin >> v[i];
	}

	int ans = 0;
	for (int i = 0; i < (1 << n); ++i)
	{
		int sumV = 0;
		bool hasSolution;

		for (int j = 0; j < n; ++j)
		{
			if (i & (1 << j))
				sumV += v[j];
		}

		if (sumV == 40)
			hasSolution = true;
		else
			hasSolution = false;

		if (hasSolution)
			ans++;
	}

	cout << ans;

	return 0;
}