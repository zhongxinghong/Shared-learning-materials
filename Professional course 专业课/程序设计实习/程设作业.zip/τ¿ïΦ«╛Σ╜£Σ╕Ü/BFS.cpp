///////////////////////////////////////////////////
///////////////////////////////////////////////////
///////////////////////////////////////////////////
	const time_t seed = time(0);
	const int dx[] = { 0, 1, 0, -1, 1, 1, -1, -1 }, dy[] = { -1, 0, 1, 0, -1, 1, 1, -1 };
	
	// 枚举定义；使用枚举虽然会浪费空间（sizeof(GridContentType) == 4），但是计算机处理32位的数字效率更高
 
	// 每个格子可能变化的内容，会采用“或”逻辑进行组合
	enum GridContentType
	{
		empty = 0, // 其实不会用到
		player1 = 1, // 1号玩家
		player2 = 2, // 2号玩家
		player3 = 4, // 3号玩家
		player4 = 8, // 4号玩家
		playerMask = 1 | 2 | 4 | 8, // 用于检查有没有玩家等
		smallFruit = 16, // 小豆子
		largeFruit = 32 // 大豆子
	};
 
	// 用玩家ID换取格子上玩家的二进制位
	GridContentType playerID2Mask[] = { player1, player2, player3, player4 };
	string playerID2str[] = { "0", "1", "2", "3" };
 
	// 让枚举也可以用这些运算了（不加会编译错误）
	template<typename T>
	inline T operator |=(T &a, const T &b)
	{
		return a = static_cast<T>(static_cast<int>(a) | static_cast<int>(b));
	}
	template<typename T>
	inline T operator |(const T &a, const T &b)
	{
		return static_cast<T>(static_cast<int>(a) | static_cast<int>(b));
	}
	template<typename T>
	inline T operator &=(T &a, const T &b)
	{
		return a = static_cast<T>(static_cast<int>(a) & static_cast<int>(b));
	}
	template<typename T>
	inline T operator &(const T &a, const T &b)
	{
		return static_cast<T>(static_cast<int>(a) & static_cast<int>(b));
	}
	template<typename T>
	inline T operator ++(T &a)
	{
		return a = static_cast<T>(static_cast<int>(a) + 1);
	}
	template<typename T>
	inline T operator ~(const T &a)
	{
		return static_cast<T>(~static_cast<int>(a));
	}
 
	// 每个格子固定的东西，会采用“或”逻辑进行组合
	enum GridStaticType
	{
		emptyWall = 0, // 其实不会用到
		wallNorth = 1, // 北墙（纵坐标减少的方向）
		wallEast = 2, // 东墙（横坐标增加的方向）
		wallSouth = 4, // 南墙（纵坐标增加的方向）
		wallWest = 8, // 西墙（横坐标减少的方向）
		generator = 16 // 豆子产生器
	};
 
	// 用移动方向换取这个方向上阻挡着的墙的二进制位
	GridStaticType direction2OpposingWall[] = { wallNorth, wallEast, wallSouth, wallWest };
 
	// 方向，可以代入dx、dy数组，同时也可以作为玩家的动作
	enum Direction
	{
		stay = -1,
		up = 0,
		right = 1,
		down = 2,
		left = 3,
		// 下面的这几个只是为了产生器程序方便，不会实际用到
		ur = 4, // 右上
		dr = 5, // 右下
		dl = 6, // 左下
		ul = 7 // 左上
	};
 
	// 场地上带有坐标的物件
	struct FieldProp             // 亦可以理解为物体的坐标……
	{
		int row, col;
		FieldProp()
		{	
		};
		
		FieldProp(const int& r, const int& c):
		row(r), col(c)
		{
			
		};
	};
	
	//有改动
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////

	
		// 判断指定位置向指定方向移动是不是合法的（没有撞墙且没有踩到豆子产生器）		
	    inline bool ActionValid(const FieldProp& p, Direction &dir)
		{
			if (dir == stay)
				return true;
			const GridStaticType &s = fieldStatic[p.row][p.col];
			return dir >= -1 && dir < 4 && !(s & direction2OpposingWall[dir]) && !(s & generator);
		}
		
		inline bool ActionValid(const int& y, const int& x, Direction &dir)
		{
			if (dir == stay)
				return true;
			const GridStaticType &s = fieldStatic[y][x];
			return dir >= -1 && dir < 4 && !(s & direction2OpposingWall[dir]) && !(s & generator);
		}
		
		

class NodeMap
{
		
public:
	int height, width;
	fieldStatic *map[];
	unsigned int DistTable[12][12][12][12];
	
	void set(const int& h, const int& w, fieldStatic *m[])
	{
		height = h; width = w; map = m;
		totEdge = 0;
		memset(DistTable, 0xFFFFFFFF, sizeof(DistTable));
		memset(DirTable, -1, sizeof(DirTable));
	}
	
	void BFS(const int& y1, const int& x1, const int& y2, const int& x2)
	{
		class node
		{
			public:
			int y, x, step;
			
			node()
			{
			};
		
			node(const int& _y, const int& _x, const int& _s):
			y(_y), x(_x), step(_s)
			{
			};
		
			bool operator == (const node& _n)
			{
				return (y == _n.y && x == _n.x);
			}
		}
	
		if ( (map[j1][i1] == generator) || (map[j2][i2] == generator) )
		{
			return;
		}
		
		node q[150]; int head. rear;
		node PreNode[12][12]; memset(PreNode, -1, sizeof(PreNode)); // PreNode的step没有意义，但是统一处理了，记录单源最短路径上每个点的前驱
		
		q[0].y = y1; q[0].x = x1; q[0].step = 0; 
		vis[y1][x1] = true;		
		head = 0 ;rear = 1;
		node cur;
		
		while (head < rear)
		{
			cur = q[head++];			
			if (cur == dest)
				break;
			
			Direction dir; int yn, xn;
			for (dir = up; dir < 8; ++dir)
			{
				
				yn = cur.y + dy[dir];
				yn = (yn + height) % height;
				xn = cur.x + dx[dir];
				xn = (xn + width) % width;
				
				if (!IsGenerator[yn][xn] && ActionValid(cur.y, cur.x, dir) && !vis[yn][xn])
				{
					vis[yn][xn] = true;
					node next(yn, xn, cur.step + 1); 
					q[rear++] = next;
					PreNode[yn][xn] = cur;
				}
			}
		}
		

		
	}
	
	
	void BFSAll()                               //之前呆狗了，写了一个dijkstra，还找了一个斐波那契堆的模板……QAQ
	{
		for (int j1 = 0; j1 < height; ++j1)
		{
			for (int i1 = 0; i1 < width; ++i1)
			{
				for (int j2 = 0; j2 < height; ++j2)
				{
					for (int i2= 0; i2 < width; ++i2)
					{
						if (!(i1 == i2 && j1 == j2) && (map[j1][i1] != generator) && (map[j2][i2] != generator))
						{
							if (DistTable[j2][i2][j1][i1] != 0xFFFFFFFF)
							{
								DistTable[j1][i1][j2][i2] = DistTable[j2][i2][j1][i1];
							}
							else
							{
								BFS(j1, i1, j2, i2);
							}
						}
					}
				}
			}
		}
	}
}