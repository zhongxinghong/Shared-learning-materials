#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdio>

using namespace std;

#define genghao2 sqrt(2.0)

int steps, count = 1;
char dir[2], useless;
double x = 0, y = 0, dist;
char check;
bool p = false;

void output()
{
	dist = sqrt(pow(x, 2.0) + pow(y, 2.0));
		
	cout << fixed << setprecision(3) << "Map #" << count++ << endl;
	cout << fixed << setprecision(3) << "The treasure is located at (" << x << "," << y << ")." << endl;
	cout << fixed << setprecision(3) << "The distance to the treasure is " << dist << "." << endl << endl;
		
	x = y = 0;
	cin.get();
}

int main()
{
	check = cin.peek();

	while (check != 'E')
	{
		cin >> steps >> dir[0];

		check = cin.peek();

		if (check != ',' && check != '.')
		{
			cin >> dir[1];
			p = true;
		}

		cin >> useless;

		switch (dir[0])
		{
			case 'N': 
				if(!p) y += steps;
				else if (dir[1] == 'E')
				{
					x += genghao2 * (steps / 2.0); 
					y += genghao2 * (steps / 2.0);
				}
				else if (dir[1] == 'W')
				{
					x -= genghao2 * (steps / 2.0);
					y += genghao2 * (steps / 2.0);
				}
				break;

			case 'E': x += steps; break;

			case 'S':
				if(!p) y -= steps;
				else if (dir[1] == 'E')
				{
					x += genghao2 * (steps / 2.0); 
					y -= genghao2 * (steps / 2.0);
				}
				else if (dir[1] == 'W')
				{
					x -= genghao2 * (steps / 2.0); 
					y -= genghao2 * (steps / 2.0);
				}
				break;

			case 'W': x -= steps; break;
		}

		if (useless == '.')
			output();
		
		check = cin.peek();
		p = false;
	}
	
	return 0;
}
