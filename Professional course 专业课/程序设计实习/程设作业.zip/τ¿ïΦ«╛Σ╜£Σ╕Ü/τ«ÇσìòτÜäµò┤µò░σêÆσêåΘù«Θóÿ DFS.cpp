#include <cstdio>
#include<iostream>

using namespace std;

int n;

int DFS(int res, int minx)
{
	if (res == 0 || res == minx)
		return 1;

	if (res < minx)
		return 0;
	if (res < 2 * minx)
		return 1;


	int ans = 0;
	for (int i = minx; i <= res; ++i)
	{
		ans += DFS(res - i, i);
	}

	return ans;
}

int work()
{
	int ans = 0;
	for (int i = 1; i <= n; ++i)
		ans += DFS(n - i, i);

	printf("%d\n", ans);

}

int main()
{
	while (	scanf("%d", &n) != EOF)
		work();
		
	return 0;
}
