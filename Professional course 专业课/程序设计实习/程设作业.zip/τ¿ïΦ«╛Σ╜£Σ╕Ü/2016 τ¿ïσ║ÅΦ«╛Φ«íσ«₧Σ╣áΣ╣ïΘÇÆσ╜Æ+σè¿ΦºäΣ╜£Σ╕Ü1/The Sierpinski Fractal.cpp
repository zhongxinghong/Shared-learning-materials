#include <cstdio>
#include <cstring>

using namespace std;

char tab[2048][2048];
int n;

void makeTriangle(const int & ys, const int & xs, const int & dep)
{
	if (dep == 1)
	{
		tab[ys][xs] = '/';
		tab[ys + 1][xs - 1] = '/';
		tab[ys + 1][xs] = tab[ys + 1][xs + 1] = '_';
		tab[ys][xs + 1] = '\\';
		tab[ys + 1][xs + 2] = '\\';
	}
	else
	{
		makeTriangle(ys, xs, dep - 1);
		makeTriangle(ys + (1 << (dep - 1)), xs - (1 << (dep - 1)), dep - 1);
		makeTriangle(ys + (1 << (dep - 1)), xs + (1 << (dep - 1)), dep - 1);
	}
}

int main()
{

	memset(tab, ' ', sizeof(tab));
	makeTriangle(1, 1<< 10, 10);
		
	scanf("%d", &n);
	while (n != 0)
	{
		int col0 = (1 << 10) - (1 << n);

		for (int i = 1; i <= (1 << n); ++i)
		{
			for (int j = 1; j <= (1 << (n + 1)); ++j)
			{
				printf("%c", tab[i][col0 + j]);
			}
			if (i < (1 << n))
				printf("\n");				
		}

		scanf("%d", &n);
		if (n != 0)
		{
			printf("\n\n");							
		}		
	}

	return 0;
}
