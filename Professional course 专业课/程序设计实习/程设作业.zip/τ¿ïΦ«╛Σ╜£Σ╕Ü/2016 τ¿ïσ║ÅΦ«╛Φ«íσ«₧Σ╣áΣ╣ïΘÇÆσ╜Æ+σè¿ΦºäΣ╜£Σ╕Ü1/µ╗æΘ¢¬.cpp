#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

#define max(a,b) (a > b ? a : b)

using namespace std;

class point
{
public:
	int y, x;
	unsigned int h;

	point()
	{
		x = 0; y = 0; h = 0xFFFFFFFF;
	}

	point(const int & _y, const int & _x, const int & _h)
	{
		y = _y; x = _x; h = _h;
	}

	friend bool operator < (const point a, const point & b)
	{
		return (a.h < b.h);
	};

	bool IfAdj(const point & b)
	{
		return ((x == b.x && (y == b.y - 1)) ||
			(x == b.x && (y == b.y + 1)) ||
			((x == b.x - 1) && y == b.y) ||
			((x == b.x + 1) && y == b.y));
	}
};

int l[20000];
int tmph, R, C;

int main()
{
	memset(l, 0, sizeof(l));

	point Points[20000];
	int cnt = 0;
	scanf("%d %d", &R, &C);
	for (int i = 1; i <= R; ++i)
	{
		for (int j = 1; j <= C; ++j)
		{
			scanf("%d", &tmph);
			Points[cnt] = point(i, j, tmph);
			++cnt;
		}
	}

	sort(Points, Points + cnt);


	for (int i = 1; i < R * C; ++i)
	{
		int maxl = -10;
		for (int j = 0; j < i; ++j)
		{
			if (Points[i].h > Points[j].h && Points[i].IfAdj(Points[j]) && l[j] > maxl)
				maxl = l[j] + 1;
		}
		l[i] = max(maxl, 0);
	}

	int res = -1;
	for (int i = 0; i < R * C; ++i)
	{
		if (l[i] > res)
			res = l[i];
	}

	cout << res + 1;

	return 0;
}
