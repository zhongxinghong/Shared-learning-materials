#include <iostream> 
#include <cstring> 
#include <cstdlib> 
#include <cstdio> 
using namespace std;
const int MAX = 110; 
class CHugeInt {
// �ڴ˴�������Ĵ���
private:
	int size;
	int val[220];
	
public:
	
	CHugeInt()
	{
		size = 0;
		memset(val, 0, sizeof(val));
	}
	
	CHugeInt(int n)
	{
		size = 0 ;
		memset(val, 0, sizeof(val));
		while (n)
		{
			val[++size] = n % 10;
			n /= 10;
		}
	}

	CHugeInt(char* s)
	{
		size = strlen(s);
		memset(val, 0, sizeof(val));
		for (int i = 1; i <= size; i++)
		{
			val[i] = s[size - i] - '0';
		}
	}
	
	CHugeInt(const CHugeInt& x)
	{
		size = x.size;
		memcpy(val, x.val, sizeof(val));
	}
	
	~CHugeInt()
	{
	}
	
	CHugeInt operator + (const CHugeInt& a)
	{
		CHugeInt tmp(a);
		int l = (a.size > size) ? a.size : size;
		for (int i = 1; i <= l; i++)
		{
			tmp.val[i] += val[i];
			tmp.val[i + 1] += tmp.val[i] / 10;
			tmp.val[i] %= 10;
		}
		while (tmp.val[l + 1])
		{
			l++;
			tmp.val[l + 1] += tmp.val[l] / 10;
			tmp.val[l] %= 10;
		}
		tmp.size = l;
		
		return tmp;
	}

	CHugeInt operator ++()
	{
		val[1]++;
		for (int i = 1; i <= size; i++)
		{
			val[i + 1] += val[i] / 10;
			val[i] %= 10;
		}
		if (val[size + 1])
			size++;

		return *this;
	}
	
	CHugeInt operator ++(int k)
	{
		CHugeInt tmp(*this);

		val[1]++;
		for (int i = 1; i <= size; i++)
		{
			val[i + 1] += val[i] / 10;
			val[i] %= 10;
		}
		if (val[size + 1])
			size++;

		return tmp;
	}
	
	CHugeInt operator + (const int& n)
	{
		CHugeInt tmp(n);
		
		return (*this + tmp);
	}
	
	CHugeInt operator += (const int& n)
	{
		*this = *this + n;		
		return (*this);
	}	
	
	friend CHugeInt operator + (int& n, CHugeInt& x)
	{
		CHugeInt tmp(x);
		tmp += n;
		return tmp;
	}
	
	friend CHugeInt operator + (CHugeInt& x, int& n)
	{
		CHugeInt tmp(x);
		tmp += n;
		return tmp;
	}
	
	friend ostream& operator << (ostream& o, const CHugeInt& x)
	{
		for (int i = x.size; i > 0; i--)
		{
			cout << x.val[i];
		}
		return o;
	}
//
};
int  main() 
{ 
	char s[210];
	int n;

	while (cin >> s >> n) {
		CHugeInt a(s);
		CHugeInt b(n);

		cout << a + b << endl;
		cout << n + a << endl;
		cout << a + n << endl;
		b += n;
		cout  << ++ b << endl;
		cout << b++ << endl;
		cout << b << endl;
	}
	return 0;
}
