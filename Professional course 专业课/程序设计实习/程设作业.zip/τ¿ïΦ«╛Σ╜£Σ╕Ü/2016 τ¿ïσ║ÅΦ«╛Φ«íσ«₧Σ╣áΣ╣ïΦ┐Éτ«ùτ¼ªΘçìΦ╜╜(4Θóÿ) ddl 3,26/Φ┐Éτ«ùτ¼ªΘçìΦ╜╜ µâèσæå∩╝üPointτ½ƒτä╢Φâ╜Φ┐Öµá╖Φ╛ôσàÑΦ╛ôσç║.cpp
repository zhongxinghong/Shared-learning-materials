#include <iostream> 
using namespace std;
class Point { 
	private: 
		int x; 
		int y; 
	public: 
		Point() { };
// �ڴ˴�������Ĵ���
    


    friend ostream& operator<<(ostream& x, Point& p)
    {
    	x<< p.x << ',' << p.y;
    	return x;
    }
    
    friend istream& operator>>(istream& x, Point& p)
    {
    	x>> p.x >> p.y;
    	return x;
	}
    

};

//
 
int main() 
{ 
 	Point p;
 	while(cin >> p) {
 		cout << p << endl;
	 }
	return 0;
}
