#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>

#define min(a, b) ( a< b ? a : b)
#define max(a, b) (a > b ? a : b)

using namespace std;

int dx[4] = { -1, 1, 0, 0 };
int dy[4] = { 0, 0, -1, 1 };

short vis[210][210];
char a[210][210];
unsigned int midL[210][210];

int N, M, t;
int edi, edj, sti, stj, minLen;

inline void Init()
{
	memset(vis, 0, sizeof(vis));
	memset(a, '#', sizeof(a));
	memset(midL, 0xFFFFFFFF, sizeof(midL));

	scanf("%d %d\n", &N, &M);
	for (int i = 1; i <= N; ++i)
	{
		for (int j = 1; j <= M; ++j)
		{
			scanf("%c", &a[i][j]);
			if (a[i][j] == 'r')
			{
				sti = i;
				stj = j;
			}
			else if (a[i][j] == 'a')
			{
				edi = i;
				edj = j;
			}
		}
		if (t > 0 || i < N)
			scanf("\n");
	};
}

void DFS(int y, int x, int dep)
{
	if (dep + (abs(y - edi) + abs(x - edj)) >= minLen)
		return;

	if (dep >= midL[y][x])
		return;

	midL[y][x] - dep;

	if (a[y][x] == 'a')
	{
		minLen = min(minLen, dep);
	}

	for (int d = 0; d < 4; ++d)
	{
		int ny = y + dy[d];
		int nx = x + dx[d];

		if (a[ny][nx] == '#' || vis[ny][nx] > 0)
			continue;

		if (a[ny][nx] == 'x')
		{
			vis[ny][nx] = 1;
			DFS(ny, nx, dep + 2);
			vis[ny][nx] = 0;
		}
		else
		{
			vis[ny][nx] = 1;
			DFS(ny, nx, dep + 1);
			vis[ny][nx] = 0;
		}
	}


}

inline void work()
{
	Init();

	minLen = INT_MAX;
	vis[sti][stj] = 1;
	DFS(sti, stj, 0);

	if (minLen < INT_MAX)
	{
		printf("%d\n", minLen);
	}
	else
	{
		printf("Impossible\n");
	}

}

int main()
{
	scanf("%d\n", &t);
	while (t--)
		work();

	return 0;
}
