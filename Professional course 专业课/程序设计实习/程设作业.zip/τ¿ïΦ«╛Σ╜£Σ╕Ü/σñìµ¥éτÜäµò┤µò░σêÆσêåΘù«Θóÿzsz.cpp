#include <iostream>
#include <algorithm>
using namespace std;
int Aid1[55][60] = { 0 }, Aid2[55] = { 0 }, Aid3[55] = { 0 };
int main()
{
	cin.sync_with_stdio(false);
	int n, k;
	Aid1[0][0] = Aid2[0] = Aid3[0] = 1;
	for (int i = 1; i < 55; ++i)
	{
		for (int j = 54; j >= i; --j)
		{
			Aid2[j] += Aid2[j - i];
			int end = j / i;
			for (int k = 1; k <= end; ++k)
				for (int l = k; l < 60; ++l)
					Aid1[j][l] += Aid1[j - k * i][l - k];
			if (i % 2 == 1)
			{
				for (int k = 1; k <= end; ++k)
					Aid3[j] += Aid3[j - i * k];
			}
		}
	}
	while (cin >> n >> k)
	{
		cout << Aid1[n][k] << endl;
		cout << Aid2[n] << endl;
		cout << Aid3[n] << endl;
	}
	return 0;
}