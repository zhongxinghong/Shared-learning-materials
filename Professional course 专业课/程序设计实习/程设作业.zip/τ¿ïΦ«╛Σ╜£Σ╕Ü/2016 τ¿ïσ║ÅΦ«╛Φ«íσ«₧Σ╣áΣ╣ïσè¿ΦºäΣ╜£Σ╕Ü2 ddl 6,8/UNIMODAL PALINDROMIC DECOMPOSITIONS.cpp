#include <iostream>
#include <cstdio>
#include <cstdlib>


using namespace std;

const int M = 260;
long long cnt[300][300] = {}; 
int n; 	


int main()
{
	cin >> n; 	

	for (int L = 1; L <= M; ++L) 	
	{ 	
		cnt[L][0] = 1;
	} 	
	for (int S = 1; S <= M; ++S) 	
	{ 		
		cnt[1][S] = 1; 		
		cnt[2][S] = (S + 1) % 2; 	
	} 

	for (int L = 3; L <= M; ++L) 	
	{ 		
		for (int S = 1; S <= M; ++S) 		
		{ 	
			for (int E = 0; ; ++E) 			
			{ 				
				if (S - E * L >= 0)
					cnt[L][S] += cnt[L - 2][S - E * L]; 				
				else break; 			
			} 		
		} 	
	} 

	while (n) 
	{
	 	cout << n << ' ' << cnt[n][n] + cnt[n + 1][n] << endl; 		
	 	cin >> n; 	
	} 	
	
	return 0; 
}