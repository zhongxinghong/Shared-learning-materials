#include <iostream>
#include <cstdio>
#include <cstdio>

using namespace std;

int n, m; 
int w[4000] = { 0 };
int d[4000] = { 0 }; 
int f[20000] = { 0 };

int main()
{ 	
	cin >> n >> m; 	

	for (int i = 1; i <= n; ++i)
	{
		cin >> w[i] >> d[i];
	} 	
	
	for (int i = 1; i <= n; ++i) 		
		for (int j = m; j >= w[i]; --j) 		
		{ 	
			f[j] = max(f[j], f[j - w[i]] + d[i]);		
		} 	

	cout << f[m] << endl;

	return 0;
}