#include <cstdio>
#include <iostream>
#include <cstring>

#define MAXN 51

using namespace std;

int n, kk;
int f1[60][60];
int f2[60];
int f3[60];


int main()
{
	memset(f1, 0, sizeof(f1));
	memset(f2, 0 ,sizeof(f2));
	memset(f3, 0 ,sizeof(f3));

	register int i, j, k;
	
	f1[0][0] = 1;
	f2[0] = 1;
	f3[0] = 1;
		
	for (i = 1; i < MAXN; ++i)
	{
		for (j = MAXN; j >= i ; --j)
		{
			int TI = j / i;
			for (k = 1; k <= j; ++k)
			{
				for (int t = 1; t <= TI && t <= k; ++t)
					f1[j][k] += f1[j - t * i][k - t];
			}
		
			f2[j] += f2[j - i];
			if (i & 1)
			{
				for (int t = 1; t <= TI; ++t)
					f3[j] += f3[j - t * i];					
			}
		}
	}


	while (scanf("%d %d", &n, &kk) != EOF)
		printf("%d\n%d\n%d\n", f1[n][kk], f2[n], f3[n]);

	return 0;
}