#include <cstdio>
#include <cstdlib>
#include <iostream>

#define MAXN 2147483647

using namespace std;

int a[17], b, w, minStep, prun;  

void up(int i)
{  
    if(i - 4 >= 0)
    {  
        if(a[i - 4] == 0)
        {  
            a[i - 4] = 1;
            w--;
            b++;
        }  
        else
        {  
            a[i - 4] = 0;
            w++;
            b--;
        }
    }  
}

void down(int i)  
{  
    if(i + 4 < 16)  
    {  
        if(a[i + 4]==0)  
        {  
            a[i + 4] = 1;  
            w--;  
            b++;  
        }  
        else  
        {  
            a[i + 4] = 0;  
            w++;  
            b--;  
        }  
    }  
}

void left(int i)  
{  
    if(i > 0 && i / 4 == (i - 1) / 4)  
    {  
        if(a[i - 1] == 0)
        {
            a[i - 1] = 1;
            w--;
            b++;
        }  
        else
        {  
            a[i - 1] = 0;  
            w++;  
            b--;  
        }  
    }  
}

void right(int i)  
{  
    if(i + 1 < 16 && i / 4 == (i + 1) / 4)  
    {  
        if(a[i + 1] == 0)  
        {  
            a[i + 1] = 1;  
            w--;  
            b++;  
        }
        else
        {  
            a[i + 1] = 0;  
            w++;  
            b--;  
        }
    }
}

void func(int i)  
{  
    int j;  
    if(i == -1)  
    {  
        for(j = i + 1; j < 16; ++j)  
        {  
            func(j);  
        }  
    }  
    else  
    {  
        if(prun == 0 && (b == 0 || w == 0))  
        {  
            minStep = prun;  
            return;  
        }  
        if(i >= 0 && i < 16)  
    {  
        if(a[i] == 0)  
        {  
            a[i]=1;  
            w--;  
            b++;  
        }  
        else  
        {  
            a[i]=0;  
            w++;  
            b--;  
        }  
    }  
        up(i);  
        down(i);  
        left(i);  
        right(i);  
        prun++;  
        if((b==0 || w==0) && minStep > prun)  
        {  
            minStep=prun;  
        }  
        else  
        {  
            for(j=i+1; j<16; j++)  
            {  
                func(j);  
            }  
  
        }  
        if(i>=0&&i<16)  
    {  
        if(a[i]==0)  
        {  
            a[i]=1;  
            w--;  
            b++;  
        }  
        else  
        {  
            a[i]=0;  
            w++;  
            b--;  
        }  
    }  
        up(i);  
        down(i);  
        left(i);  
        right(i);  
        prun--;  
    }  
}  

void work()
{
        b=0; w=0; prun=0;
        minStep = MAXN;

        for(int i = 0; i<4; i++)  
        {
            if(s[i]=='b')  
            {  
                a[i]=1;  
                b++;  
            }  
            else if(s[i]=='w')  
            {  
                a[i]=0;  
                w++;  
            }  
        }  
        for(int i=1; i<4; i++)  
        {  
            scanf("%s",s);  
            for(int j=0; j<4; j++)  
            {  
                if(s[j]=='b')  
                {  
                    a[i*4+j]=1;  
                    b++;  
                }  
                else if(s[j]=='w')  
                {  
                    a[i*4+j]=0;  
                    w++;  
                }  
            }  
        }

        func(-1);

        if(minStep != MAXN)
            printf("%d\n",minStep);
        else
            printf("Impossible\n");
}

int main()  
{
    char s[6];
    while(scanf("%s",s) != EOF)
        work();
    return 0;  
}