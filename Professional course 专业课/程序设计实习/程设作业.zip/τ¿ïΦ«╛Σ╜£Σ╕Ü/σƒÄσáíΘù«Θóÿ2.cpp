#include <cstdio>
#include <climits>
#include <stack>

#define max(a, b) (a > b ? a : b)

using std::stack;

int m, n, totSize, visitedSize, totRoom, maxRoom, tmpS;
int map[60][60] = { 0 };
short vis[60][60] = { 0 };

int dx[4] = { 0, -1, 0, 1 };
int dy[4] = { -1, 0, 1, 0 };


inline bool ActionValid(const int & x, const int & y, const int & d)
{
	int nx = dx[d] + x;
	int ny = dy[d] + y;
	if (nx < 1 || nx > m || ny < 1 || ny > n)
		return false;

	if (map[x][y] & (1 << d))
		return false;

	if (vis[nx][ny])
		return false;

	return true;
}

struct grid
{
	int r, c;

	grid(int & _r, int & _c)
	{
		r = _r;
		c = _c;
	}
};

void DFS(int i, int j)
{
	stack< grid > stk;
	stk.push(grid(i, j));
	vis[i][j] = 1;
	++tmpS;

	while (!stk.empty())
	{
		grid ttop = stk.top();
		int px = ttop.r;
		int py = ttop.c;
		int braunchNum = 0;

		for (int d = 0; d < 4; ++d)
		{
			if (ActionValid(px, py, d))
			{
				braunchNum++;
				int nx = px + dx[d];
				int ny = py + dy[d];
				stk.push(grid(nx, ny));
				vis[nx][ny] = 1;
				++tmpS;
			}
		}

		if (braunchNum == 0)
			stk.pop();
	}
}

int main()
{
	scanf("%d%d", &m, &n);
	for (int i = 1; i <= m; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			scanf("%d", &map[i][j]);
		}
	}

	totSize = n * m;
	visitedSize = 0;
	totRoom = 0;
	maxRoom = INT_MIN;

	for (int i = 1; i <= m; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			if (visitedSize >= totSize)
				break;

			if (vis[i][j])
				continue;

			tmpS = 0;
			DFS(i, j);
			totRoom++;
			visitedSize += tmpS;
			maxRoom = max(maxRoom, tmpS);
		}
	}


	printf("%d\n%d", totRoom, maxRoom);


	return 0;
}
