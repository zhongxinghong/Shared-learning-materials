#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>
#include <vector>
#include <queue>

#define min(a, b) ( a< b ? a : b)
#define max(a, b) (a > b ? a : b)

using namespace std;

int dx[4] = { -1, 1, 0, 0 };
int dy[4] = { 0, 0, -1, 1 };

short vis[210][210];
char a[210][210];

bool hasSolution;
int N, M, t;
int edi, edj, sti, stj;

struct pos
{
	int r, c, type, steps;
	pos()
	{};
	pos(int _r, int _c, int _t, int _s):
	r(_r), c(_c), type(_t), steps(_s)
	{};
};

queue < pos > q;

inline void Init()
{
	memset(vis, 0, sizeof(vis));
	memset(a, '#', sizeof(a));

	while (!q.empty())
		q.pop();

	scanf("%d %d\n", &N, &M);
	for (int i = 1; i <= N; ++i)
	{
		for (int j = 1; j <= M; ++j)
		{
			scanf("%c", &a[i][j]);
			if (a[i][j] == 'r')
			{
				sti = i;
				stj = j;
			}
			else if (a[i][j] == 'a')
			{
				edi = i;
				edj = j;
			}
		}
		if (t > 0 || i < N)
			scanf("\n");
	};
}

inline void work()
{
	Init();

	hasSolution = false;
	
	vis[sti][stj] = 1;
	q.push(pos(sti, stj, 0, 0));
	
	pos tmp;
	while (!q.empty())
	{
		tmp = q.front();
		if (tmp.r == edi && tmp.c == edj)
		{
			hasSolution = true;
			break;			
		}

		q.pop();

		if (tmp.type == 1)
		{
			q.push( pos(tmp.r, tmp.c, 0, tmp.steps + 1) );
		}
		else
		{
			for (int d = 0; d < 4; ++d)
			{
				int nr = tmp.r + dy[d];
				int nc = tmp.c + dx[d];

				if (a[nr][nc] == '#' || vis[nr][nc] > 0)
					continue;

				if (a[nr][nc] == 'x')
				{
					vis[nr][nc] = 1;
					q.push(pos(nr, nc, 1, tmp.steps + 1));
				}
				else
				{
					vis[nr][nc] = 1;
					q.push(pos(nr, nc, 0, tmp.steps + 1));
				}
			}
		}

	}

	if (hasSolution)
	{
		printf("%d\n", tmp.steps);
	}
	else
	{
		printf("Impossible\n");
	}

}

int main()
{
	scanf("%d\n", &t);
	while (t--)
		work();

	return 0;
}
