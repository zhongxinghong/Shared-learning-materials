#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

int v[100] = {0};
int sum[100][100] = {0};
int n;

int main()
{
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> v[i];

	for (int i = 0; i <= n; ++i)
		sum[0][i] = 1;

	for (int vt = 1; vt <= 40; ++vt)
		for (int k = 1; k <= n; ++k)
		{
			sum[vt][k] = sum[vt][k - 1];
			if (vt >= v[k])
				sum[vt][k] += sum[vt - v[k]][k - 1];
		}

	cout << sum[40][n];
	
	return 0;	
}
